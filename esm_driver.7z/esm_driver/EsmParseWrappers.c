#include "EsmParseWrappers.h"
#include "cli.h"
#include "CliUtilities.h"

#include "author_family.h"
#include "port_manager_api.h"
#include "mip_def_values.h"
#include "mip_ESM_DRIVER.h"
#include "mip_DISTRIB.h"
#include "mip_PMAP.h"
#include "mip_PORT_MANAGER.h"
#include "mip_PTP.h"
#include <port_library_api.h>
static int statsVal = 1;

#define sysMemorySize 0x10000000

void WRPesmShowInterfacesEmp(CliSubparserGlobals *globals)
{
	MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
	int32		mipIndexLength=0;
	int32     done;

	SetActionAllFamily(globals,  PM_FAMILY_INTERFACES, PARTM_EUP_AREA_PHYSICAL);
	ReadAction(globals);
	if (CliCheckAll(globals))
		return;

	if(CliDebugMip(globals))
		printf("WRPesmShowInterfacesEmp()\n");

	mipIndex[0] = 0;

	do{
		WRPshow(globals, APPID_SYSTEM_SERVICES, SNAPID_SS_CMM_MIP);
		//WRPmip_write_ascii_all(globals, MIP_ALL);
		WRPmip_write_ascii_req(globals, 1,  MIP_DISP_SYS_EMP_STATUS, mipIndexLength, mipIndex);
   	done = WRPdone(globals, &mipIndexLength, mipIndex);
	}while(!done);
}


void WRPesmShowInterfacesXXX(CliSubparserGlobals *globals, int table, int type,
    int start_ifIndex_field, int end_ifIndex_field,
    int count, cliChassisSlotPort *slotport) {

	MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
	int32		mipIndexLength=0;
	int32       done;

	SetActionAllFamily(globals,  PM_FAMILY_INTERFACES, PARTM_EUP_AREA_PHYSICAL);
	ReadAction(globals);
	if (CliCheckAll(globals))
		return;

	if(CliDebugMip(globals))
		printf("WRPesmShowInterfacesXXX(\n"
				"\ttable                  %d\n"
				"\ttype                   %d\n"
				"\tstart_ifIndex_field    %d\n"
				"\tend_ifIndex_field      %d\n"
				"\tcount                  %d)\n"
			   	, table, type, start_ifIndex_field, end_ifIndex_field, count);

	mipIndex[0] = type;
    if (count)
    {
        mipIndex[1] = start_ifIndex_field;
        mipIndex[2] = end_ifIndex_field;
        mipIndexLength=3;
    }
    else
    {
        mipIndex[1]=0;
        mipIndexLength=2;
    }
//	else if (status == -1)
//	{
//		if ( slot == -1 )
//		{
//			mipIndex[1] = 0;
//		}
//		else
//		{
//			pl_ret = plGetIfIndexFromSlotPort(slot, 0, (uint32*)&(mipIndex[1]));
//			CLI_CHECK_PL_RETURN(pl_ret, globals);
//		}
//		mipIndexLength = 2;
//	}

	do
	{
		WRPshow(globals, APPID_ESM_DRIVER, SNAPID_CMM_ESM_DRIVER_MIP);
		if (!mipIndex[1])
			WRPmip_write_ascii_all(globals, MIP_ALL);
		WRPmip_write_ascii_req(globals, 1, table, mipIndexLength, mipIndex);
		done = WRPdone(globals, &mipIndexLength, mipIndex);
	} while (!done);
}


void WRPesmTrapSLOTPORTPortLinkONOFF(CliSubparserGlobals *globals, int val, int chassisId_field,
                                     int count, cliChassisSlotPort *slotport) {

	MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
	int32		mipIndexLength=0;
	int32       start_ifIndex_field,end_ifIndex_field;
    int32     num/*, startport, endport*/;

	SetActionAllFamily(globals,  PM_FAMILY_INTERFACES, PARTM_EUP_AREA_PHYSICAL);
	// Set appid for config manager preparsing
	SetActionAppId(globals, APPID_ESM_DRIVER);
	WriteAction(globals);
	if (CliCheckAll(globals))
		return;

	start_ifIndex_field=slotport[0].startIfIndex;
	end_ifIndex_field=slotport[0].endIfIndex;

	if(CliDebugMip(globals))
		printf("WRPesmTrapSLOTPORTPortLinkONOFF(\n"
				"\tval                 %d\n"
				"\tchassisId_field     %d\n"
                "\tstart_ifIndex_field %d\n"
                "\tend_ifIndex_field   %d\n"
				"\tcount               %d)\n"
			   	, val, chassisId_field,start_ifIndex_field,end_ifIndex_field, count);

	if( count )
	{
//		startport = slotport[0].startPort;
//		endport	= slotport[0].endPort;
		for(num=start_ifIndex_field; num<=end_ifIndex_field; num++) {
//			pl_ret = plGetIfIndexFromSlotPort(slotport[0].slot, num, (uint32*)&(mipIndex[mipIndexLength]));
//			CLI_CHECK_PL_RETURN(pl_ret, globals);
			mipIndex[mipIndexLength]=num;
			if ( !mipIndex[mipIndexLength] || mipIndexLength > 51 ) {
				SetFormatedDisplay(CliGetDisplayGlobals(globals), "ERROR: %s\n", ASCII_ERROR_SLOT_PORT);
				globals->cliGlobals->error = 5;
				return ;
			}
			mipIndexLength++;
		}
	}
	else {
//		pl_ret = plGetIfIndexFromSlotPort(slot, 0, (uint32*)&(mipIndex[0]));
//		CLI_CHECK_PL_RETURN(pl_ret, globals);
//		mipIndexLength = 1;
		SetFormatedDisplay(CliGetDisplayGlobals(globals), "ERROR: no ifIndex\n");
		globals->cliGlobals->error = 5;
		return ;
	}

	WRPset(globals, APPID_ESM_DRIVER, SNAPID_CMM_ESM_DRIVER_MIP);

	WRPwriteTable(globals, MIP_IFXTABLE);
	WRPwriteIndex(globals, mipIndexLength, mipIndex);
  	WRPwriteObject(globals, mip_ifLinkUpDownTrapEnable, MIP_UINT32, 4, (uint8*)&val);

	WRPmip_msg_done(globals);
	WRPmip_free_buffer(globals);
}

void WRPesmInterfaceEppEnableDisable(CliSubparserGlobals *globals,int val_field,int chassisId_field,int count_field,cliChassisSlotPort *slot_port)
{
	MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
	int32		mipIndexLength=0;
	int32     num/*, startport, endport*/;
//	pl_return_type pl_ret;
	int32       start_ifIndex_field,end_ifIndex_field;

	SetActionAllFamily(globals,  PM_FAMILY_INTERFACES, PARTM_EUP_AREA_PHYSICAL);
	// Set appid for config manager preparsing
	SetActionAppId(globals, APPID_ESM_DRIVER);
	WriteAction(globals);
	if (CliCheckAll(globals))
		return;

	start_ifIndex_field=slot_port[0].startIfIndex;
	end_ifIndex_field=slot_port[0].endIfIndex;

	if(CliDebugMip(globals))
		printf("WRPesmInterfaceEppEnableDisable(\n"
			"\tval_field            %d\n"
			"\tchassisId_field      %d\n"
			"\tstart_ifIndex_field  %d\n"
			"\tend_ifIndex_field    %d\n"
			"\tcount_field          %d)\n",
			val_field,chassisId_field,start_ifIndex_field,end_ifIndex_field,count_field);

	if(count_field)
	{
//		startport = slot_port[0].startPort;
//		endport	= slot_port[0].endPort;
		for(num=start_ifIndex_field; num<=end_ifIndex_field; num++)
		{
//			pl_ret = plGetIfIndexFromSlotPort(slot_port[0].slot, num, (uint32*)&(mipIndex[mipIndexLength]));
//			CLI_CHECK_PL_RETURN(pl_ret, globals);
			mipIndex[mipIndexLength]=num;
			if ( !mipIndex[mipIndexLength] || mipIndexLength > 50 )
			{
				SetFormatedDisplay(CliGetDisplayGlobals(globals), "ERROR: %s\n", ASCII_ERROR_SLOT_PORT);
				globals->cliGlobals->error = 5;
				return ;
			}
			mipIndexLength++;
		}
	}
	else
	{
//		pl_ret = plGetIfIndexFromSlotPort(slot_field, 0, (uint32*)&(mipIndex[0]));
//		CLI_CHECK_PL_RETURN(pl_ret, globals);
//		mipIndexLength = 1;
		SetFormatedDisplay(CliGetDisplayGlobals(globals), "ERROR: no ifIndex\n");
		globals->cliGlobals->error = 5;
		return ;
	}

	WRPset(globals, APPID_ESM_DRIVER, SNAPID_CMM_ESM_DRIVER_MIP);

	WRPwriteTable(globals, MIP_ESMCONFTABLE);
	WRPwriteIndex(globals, mipIndexLength, mipIndex);
	WRPwriteObject(globals,mip_esmPortEPPEnable,MIP_UINT32,4,(uint8 *)&val_field);

	WRPmip_msg_done(globals);
	WRPmip_free_buffer(globals);
}


void WRPesmInterfaceEeeEnableDisable(CliSubparserGlobals *globals,int val_field,int chassisId_field,int count_field,cliChassisSlotPort *slot_port)
{
	MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
	int32		mipIndexLength=0;
	int32     num;
	int32       start_ifIndex_field,end_ifIndex_field;

	SetActionAllFamily(globals,  PM_FAMILY_INTERFACES, PARTM_EUP_AREA_PHYSICAL);
	// Set appid for config manager preparsing
	SetActionAppId(globals, APPID_ESM_DRIVER);
	WriteAction(globals);
	if (CliCheckAll(globals))
		return;

	start_ifIndex_field=slot_port[0].startIfIndex;
	end_ifIndex_field=slot_port[0].endIfIndex;

	if(CliDebugMip(globals))
		printf("WRPesmInterfaceEeeEnableDisable(\n"
			"\tval_field            %d\n"
			"\tchassisId_field      %d\n"
			"\tstart_ifIndex_field  %d\n"
			"\tend_ifIndex_field    %d\n"
			"\tcount_field          %d)\n",
			val_field,chassisId_field,start_ifIndex_field,end_ifIndex_field,count_field);

	if(count_field)
	{
		for(num=start_ifIndex_field; num<=end_ifIndex_field; num++)
		{
			mipIndex[mipIndexLength]=num;
			if ( !mipIndex[mipIndexLength] || mipIndexLength > 50 )
			{
				SetFormatedDisplay(CliGetDisplayGlobals(globals), "ERROR: %s\n", ASCII_ERROR_SLOT_PORT);
				globals->cliGlobals->error = 5;
				return ;
			}
			mipIndexLength++;
		}
	}
	else
	{
		SetFormatedDisplay(CliGetDisplayGlobals(globals), "ERROR: no ifIndex\n");
		globals->cliGlobals->error = 5;
		return ;
	}

	WRPset(globals, APPID_ESM_DRIVER, SNAPID_CMM_ESM_DRIVER_MIP);

	WRPwriteTable(globals, MIP_ESMCONFTABLE);
	WRPwriteIndex(globals, mipIndexLength, mipIndex);
	WRPwriteObject(globals,mip_esmPortEEEEnable,MIP_UINT32,4,(uint8 *)&val_field);

	WRPmip_msg_done(globals);
	WRPmip_free_buffer(globals);
}

void WRPesmInterfaceTypeSLOTPORTSpeed(CliSubparserGlobals *globals, int val, int chassisId_field,
                                      int count, cliChassisSlotPort *slotport) {

	MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
	int32		mipIndexLength=0;
//    pl_return_type pl_ret;
    int32       start_ifIndex_field,end_ifIndex_field;

	SetActionAllFamily(globals,  PM_FAMILY_INTERFACES, PARTM_EUP_AREA_PHYSICAL);
	// Set appid for config manager preparsing
	SetActionAppId(globals, APPID_ESM_DRIVER);
	WriteAction(globals);
	if (CliCheckAll(globals))
		return;

    start_ifIndex_field=slotport[0].startIfIndex;
    end_ifIndex_field=slotport[0].endIfIndex;

	if(CliDebugMip(globals))
		printf("WRPesmInterfaceTypeSLOTPORTSpeed(\n"
				"\tval                 %d\n"
				"\tchassisId_field     %d\n"
                "\tstart_ifIndex_field %d\n"
                "\tend_ifIndex_field   %d\n"
				"\tcount               %d)\n"
			   	, val, chassisId_field,start_ifIndex_field,end_ifIndex_field, count);
	if( count )
    {
        mipIndex[mipIndexLength]=start_ifIndex_field;
        mipIndexLength++;
        mipIndex[mipIndexLength]=end_ifIndex_field; 
        mipIndexLength++;
	}
	else
    {
//		pl_ret = plGetIfIndexFromSlotPort(slot, 0, (uint32*)&(mipIndex[0]));
//		CLI_CHECK_PL_RETURN(pl_ret, globals);
//		mipIndexLength = 1;
        SetFormatedDisplay(CliGetDisplayGlobals(globals), "ERROR: no ifIndex\n");
        globals->cliGlobals->error = 5;
        return ;
    }

	WRPset(globals, APPID_ESM_DRIVER, SNAPID_CMM_ESM_DRIVER_MIP);

	WRPwriteTable(globals, MIP_ESMCONFTABLE);
	WRPwriteIndex(globals, mipIndexLength, mipIndex);
  	WRPwriteObject(globals, mip_esmPortCfgSpeed, MIP_UINT32, 4, (uint8*)&val);

	WRPmip_msg_done(globals);
	WRPmip_free_buffer(globals);
}


void WRPesmInterfaceTypeSLOTPORTDuplex(CliSubparserGlobals *globals, int val, int chassisId_field,
                                    int count, cliChassisSlotPort *slotport) {

	MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
	int32		mipIndexLength=0;
//	pl_return_type pl_ret;
    int32       start_ifIndex_field,end_ifIndex_field;

	SetActionAllFamily(globals,  PM_FAMILY_INTERFACES, PARTM_EUP_AREA_PHYSICAL);
	// Set appid for config manager preparsing
	SetActionAppId(globals, APPID_ESM_DRIVER);
	WriteAction(globals);
	if (CliCheckAll(globals))
		return;

    start_ifIndex_field=slotport[0].startIfIndex;
    end_ifIndex_field=slotport[0].endIfIndex;

	if(CliDebugMip(globals))
		printf("WRPesmInterfaceTypeSLOTPORTDuplex(\n"
				"\tval                 %d\n"
				"\tchassisId_field     %d\n"
                "\tstart_ifIndex_field %d\n"
                "\tend_ifIndex_field   %d\n"
				"\tcount               %d)\n"
			   	, val, chassisId_field,start_ifIndex_field,end_ifIndex_field, count);

	if( count )
    {
        mipIndex[mipIndexLength]=start_ifIndex_field;
        mipIndexLength++;
        mipIndex[mipIndexLength]=end_ifIndex_field; 
        mipIndexLength++;
	}
	else
    {
//		pl_ret = plGetIfIndexFromSlotPort(slot, 0, (uint32*)&(mipIndex[0]));
//		CLI_CHECK_PL_RETURN(pl_ret, globals);
//		mipIndexLength = 1;
        SetFormatedDisplay(CliGetDisplayGlobals(globals), "ERROR: no ifIndex\n");
        globals->cliGlobals->error = 5;
        return ;
    }

	WRPset(globals, APPID_ESM_DRIVER, SNAPID_CMM_ESM_DRIVER_MIP);

	WRPwriteTable(globals, MIP_ESMCONFTABLE);
	WRPwriteIndex(globals, mipIndexLength, mipIndex);
  	WRPwriteObject(globals, mip_esmPortCfgDuplexMode, MIP_UINT32, 4, (uint8*)&val);

	WRPmip_msg_done(globals);
	WRPmip_free_buffer(globals);
}


void WRPesmInterfaceTypeSLOTPORTAdminUp(CliSubparserGlobals *globals, int val, int chassisId_field,
                                    int count, cliChassisSlotPort *slotport) {

	MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
	int32		mipIndexLength=0;
	int32     num/*, startport, endport*/;
//    pl_return_type pl_ret;
    int32       start_ifIndex_field,end_ifIndex_field;

	SetActionAllFamily(globals,  PM_FAMILY_INTERFACES, PARTM_EUP_AREA_PHYSICAL);
	// Set appid for config manager preparsing
	SetActionAppId(globals, APPID_ESM_DRIVER);
	WriteAction(globals);
	if (CliCheckAll(globals))
		return;

    start_ifIndex_field=slotport[0].startIfIndex;
    end_ifIndex_field=slotport[0].endIfIndex;

	if(CliDebugMip(globals))
		printf("WRPesmInterfaceTypeSLOTPORTAdminUp(\n"
				"\tval                 %d\n"
				"\tchassisId_field     %d\n"
                "\tstart_ifIndex_field %d\n"
                "\tend_ifIndex_field   %d\n"
				"\tcount               %d)\n"
			   	, val, chassisId_field,start_ifIndex_field,end_ifIndex_field, count);

	if( count )
    {
//		startport = slotport[0].startPort;
//		endport	= slotport[0].endPort;
		for(num=start_ifIndex_field; num<=end_ifIndex_field; num++)
        {
//            pl_ret = plGetIfIndexFromSlotPort(slotport[0].slot, num, (uint32*)&(mipIndex[mipIndexLength]));
//            CLI_CHECK_PL_RETURN(pl_ret, globals);
            mipIndex[mipIndexLength]=num;
			if ( (!mipIndex[mipIndexLength]) || 
                (mipIndexLength >=  CLI_MIP_IDX_LENGTH)) 
            {
				SetFormatedDisplay(CliGetDisplayGlobals(globals), 
                    "ERROR: %s - Port Range exceeds CLI MAX %d\n",
                    ASCII_ERROR_SLOT_PORT, CLI_MIP_IDX_LENGTH);
				globals->cliGlobals->error = 5;
				return ;
			}
			mipIndexLength++;
		}
	}
	else
    {
//        pl_ret = plGetIfIndexFromSlotPort(slot, 0, (uint32*)&(mipIndex[0]));
//        CLI_CHECK_PL_RETURN(pl_ret, globals);
//		mipIndexLength = 1;
        SetFormatedDisplay(CliGetDisplayGlobals(globals), "ERROR: no ifIndex\n");
        globals->cliGlobals->error = 5;
        return ;
	}

	WRPset(globals, APPID_ESM_DRIVER, SNAPID_CMM_ESM_DRIVER_MIP);

	WRPwriteTable(globals, MIP_IFTABLE);
	WRPwriteIndex(globals, mipIndexLength, mipIndex);
  	WRPwriteObject(globals, mip_ifAdminStatus, MIP_UINT32, 4, (uint8*)&val);

	WRPmip_msg_done(globals);
	WRPmip_free_buffer(globals);
}

void WRPesmInterfaceTypeSLOTPORTBeaconParam(CliSubparserGlobals *globals, int ledAdminState,int ledColor,int ledMode, int chassisId_field,
        int count, cliChassisSlotPort *slotport,int portRowStatus)
{

    MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
    int32       mipIndexLength=0;
    int32       start_ifIndex_field,end_ifIndex_field;
    SetActionAllFamily(globals,  PM_FAMILY_INTERFACES, PARTM_EUP_AREA_PHYSICAL);
    // Set appid for config manager preparsing
    SetActionAppId(globals, APPID_ESM_DRIVER);
    WriteAction(globals);
    if (CliCheckAll(globals))
        return;

    start_ifIndex_field=slotport[0].startIfIndex;
    end_ifIndex_field=slotport[0].endIfIndex;

    if(CliDebugMip(globals))
        printf("%s(\n"
                "\tledAdminState       %d\n"
                "\tledColor            %d\n"
                "\tledMode             %d\n"
                "\tportRowStatus       %d\n"
                "\tchassisId_field     %d\n"
                "\tstart_ifIndex_field %d\n"
                "\tend_ifIndex_field   %d\n"
                "\tcount               %d)\n",
                __FUNCTION__,
                ledAdminState,ledColor,ledMode,portRowStatus,chassisId_field,start_ifIndex_field,end_ifIndex_field, count);

    if( count )
    {
        mipIndex[mipIndexLength]=start_ifIndex_field;
        mipIndexLength++;
        mipIndex[mipIndexLength]=end_ifIndex_field; 
        mipIndexLength++;
    }
    else
    {
        SetFormatedDisplay(CliGetDisplayGlobals(globals), "ERROR: no ifIndex\n");
        globals->cliGlobals->error = 5;
        return ;
    }

    WRPset(globals, APPID_ESM_DRIVER, SNAPID_CMM_ESM_DRIVER_MIP);

    WRPwriteTable(globals, MIP_ESMPORTBEACONTABLE);
    WRPwriteIndex(globals, mipIndexLength, mipIndex);

    if(ledAdminState != 0)
    {
        WRPwriteObject(globals, mip_esmBeaconAdminState, MIP_UINT32, 4, (uint8*)&ledAdminState);
    }

    if(ledColor != 0)
    {
        WRPwriteObject(globals, mip_esmBeaconLedColor, MIP_UINT32, 4, (uint8*)&ledColor);
    }

    if(ledMode != 0)
    {
        WRPwriteObject(globals, mip_esmBeaconLedMode, MIP_UINT32, 4, (uint8*)&ledMode);
    } 
    WRPwriteObject(globals, mip_esmBeaconRowStatus, MIP_UINT32, 4, (uint8*)&portRowStatus);

    WRPmip_msg_done(globals);
    WRPmip_free_buffer(globals);
}
void WRPesmInterfaceTypeSLOTPORTSplitMode(CliSubparserGlobals *globals, int val, int chassisId_field,
					  int count, cliChassisSlotPort *slotport)
{
	MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
	int32		mipIndexLength=0;
	int32     num/*, startport, endport*/;
	int32       start_ifIndex_field,end_ifIndex_field;

	SetActionAllFamily(globals,  PM_FAMILY_INTERFACES, PARTM_EUP_AREA_PHYSICAL);
	// Set appid for config manager preparsing
	SetActionAppId(globals, APPID_ESM_DRIVER);
	WriteAction(globals);
	if (CliCheckAll(globals))
		return;


	start_ifIndex_field=slotport[0].startIfIndex;
	end_ifIndex_field=slotport[0].endIfIndex;

	if(CliDebugMip(globals))
		printf("%s(\n"
			"\tval                 %d\n"
			"\tchassisId_field     %d\n"
			"\tstart_ifIndex_field %d\n"
			"\tend_ifIndex_field   %d\n"
			"\tcount               %d)\n",
			__FUNCTION__,
			val, chassisId_field,start_ifIndex_field,end_ifIndex_field, count);

	if( count )
	{
		for(num=start_ifIndex_field; num<=end_ifIndex_field; num++)
		{
			mipIndex[mipIndexLength]=num;
			if ( (!mipIndex[mipIndexLength]) || 
			     (mipIndexLength >=  CLI_MIP_IDX_LENGTH) ) 
			{
				SetFormatedDisplay(CliGetDisplayGlobals(globals), 
						   "ERROR: %s - Port Range exceeds CLI MAX %d\n",
						   ASCII_ERROR_SLOT_PORT, CLI_MIP_IDX_LENGTH);
				globals->cliGlobals->error = 5;
				return ;
			}
			mipIndexLength++;
		}
	}
	else
	{
		SetFormatedDisplay(CliGetDisplayGlobals(globals), "ERROR: no ifIndex\n");
		globals->cliGlobals->error = 5;
		return ;
	}

	WRPset(globals, APPID_ESM_DRIVER, SNAPID_CMM_ESM_DRIVER_MIP);

	WRPwriteTable(globals, MIP_ESMPORTMODETABLE);
	WRPwriteIndex(globals, mipIndexLength, mipIndex);
	WRPwriteObject(globals, mip_esmConfiguredMode, MIP_UINT32, 4, (uint8*)&val);

	WRPmip_msg_done(globals);
	WRPmip_free_buffer(globals);
}


void WRPesmInterfaceTypeSLOTPORTNoL2Statistics(CliSubparserGlobals *globals, int chassisId_field,
                                   int count, cliChassisSlotPort *slotport) {

	MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
	int32		mipIndexLength=0;
//	pl_return_type pl_ret;
	int32       start_ifIndex_field,end_ifIndex_field;

	SetActionAllFamily(globals,  PM_FAMILY_INTERFACES, PARTM_EUP_AREA_PHYSICAL);
	// Set appid for config manager preparsing
	SetActionAppId(globals, APPID_ESM_DRIVER);
	WriteAction(globals);
	if (CliCheckAll(globals))
		return;

	start_ifIndex_field=slotport[0].startIfIndex;
	end_ifIndex_field=slotport[0].endIfIndex;

	if(CliDebugMip(globals))
		printf("WRPesmInterfaceTypeSLOTPORTNoL2Statistics(\n"
				"\tchassisId_field     %d\n"
                "\tstart_ifIndex_field %d\n"
                "\tend_ifIndex_field   %d\n"
				"\tcount               %d)\n"
			   	, chassisId_field,start_ifIndex_field,end_ifIndex_field, count);

	if( count )
    {
        mipIndex[mipIndexLength]=start_ifIndex_field;
        mipIndexLength++;
        mipIndex[mipIndexLength]=end_ifIndex_field; 
        mipIndexLength++;
	}
	else
    {
//		pl_ret = plGetIfIndexFromSlotPort(slot, 0, (uint32*)&(mipIndex[0]));
//		CLI_CHECK_PL_RETURN(pl_ret, globals);
//		mipIndexLength = 1;
        SetFormatedDisplay(CliGetDisplayGlobals(globals), "ERROR: no ifIndex\n");
        globals->cliGlobals->error = 5;
        return ;
	}

	WRPset(globals, APPID_ESM_DRIVER, SNAPID_CMM_ESM_DRIVER_MIP);

	WRPwriteTable(globals, MIP_ALCETHERSTATSTABLE);
	WRPwriteIndex(globals, mipIndexLength, mipIndex);
  	WRPwriteObject(globals, mip_alcetherClearStats, MIP_UINT32, 4,  (uint8*)&statsVal);

	WRPmip_msg_done(globals);
	WRPmip_free_buffer(globals);
}

void WRPesmInterfaceTypeSLOTPORTNoL2StatisticsCli(CliSubparserGlobals *globals, int slot,
                                   int count, cliChassisSlotPort *slotport) {

	MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
	int32		mipIndexLength = 0;
//	pl_return_type pl_ret;
    int32       start_ifIndex_field,end_ifIndex_field;
    int32     done;

	SetActionAllFamily(globals,  PM_FAMILY_INTERFACES, PARTM_EUP_AREA_PHYSICAL);
	ReadAction(globals);
	if (CliCheckAll(globals))
		return;

    start_ifIndex_field=slotport[0].startIfIndex;
    end_ifIndex_field=slotport[0].endIfIndex;

	if(CliDebugMip(globals))
		printf("WRPesmInterfaceTypeSLOTPORTNoL2StatisticsCli(\n"
			"\tslot                %d\n"
            "\tstart_ifIndex_field %d\n"
            "\tend_ifIndex_field   %d\n"
			"\tcount               %d)\n"
		   	, slot,start_ifIndex_field,end_ifIndex_field, count);
	mipIndex[mipIndexLength++] = 0;

	if( count )
    {
        mipIndex[mipIndexLength]=start_ifIndex_field;
        mipIndexLength++;
        mipIndex[mipIndexLength]=end_ifIndex_field; 
        mipIndexLength++;
	}
	else {
        mipIndex[1]=0;
        mipIndexLength=2;
	}

	do{
		WRPshow(globals, APPID_ESM_DRIVER, SNAPID_CMM_ESM_DRIVER_MIP);
        if (!mipIndex[1])
            WRPmip_write_ascii_all(globals, MIP_ALL);
		WRPmip_write_ascii_req(globals, 1,  MIP_RESET_CLI_INTERFACES_STATS, mipIndexLength, mipIndex);
		done = WRPdone(globals, &mipIndexLength, mipIndex);
	}while(!done);
}

void WRPesmInterfaceTypeSLOTPORTNoL2StatisticsAll(CliSubparserGlobals *globals)
{
    MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
    int32       mipIndexLength = 0;
    int32       done;

    SetActionAllFamily(globals, PM_FAMILY_INTERFACES, PARTM_EUP_AREA_PHYSICAL);
    ReadAction(globals);
    if (CliCheckAll(globals))
        return;

    if(CliDebugMip(globals))
        printf("%s()\n",__FUNCTION__);

    mipIndex[0]=0;
    mipIndex[1]=0;
    mipIndexLength=2;

    do{
        WRPshow(globals, APPID_ESM_DRIVER, SNAPID_CMM_ESM_DRIVER_MIP);
        if (!mipIndex[1])
            WRPmip_write_ascii_all(globals, MIP_ALL);
        WRPmip_write_ascii_req(globals, 1,  MIP_RESET_ALL_INTERFACES_STATS, mipIndexLength, mipIndex);
        done = WRPdone(globals, &mipIndexLength, mipIndex);
    }while(!done);
}

void WRPesmInterfaceTypeSLOTPORTMaxFrame(CliSubparserGlobals *globals, int val, int chassisId_field,
                                    int count, cliChassisSlotPort *slotport) {

	MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
	int32		mipIndexLength=0;
//	pl_return_type pl_ret;
    int32       start_ifIndex_field,end_ifIndex_field;

	SetActionAllFamily(globals,  PM_FAMILY_INTERFACES, PARTM_EUP_AREA_PHYSICAL);
	// Set appid for config manager preparsing
	SetActionAppId(globals, APPID_ESM_DRIVER);
	WriteAction(globals);
	if (CliCheckAll(globals))
		return;

    start_ifIndex_field=slotport[0].startIfIndex;
    end_ifIndex_field=slotport[0].endIfIndex;

	if(CliDebugMip(globals))
		printf("WRPesmInterfaceTypeSLOTPORTMaxFrame(\n"
				"\tval                 %d\n"
				"\tchassisId_field     %d\n"
                "\tstart_ifIndex_field %d\n"
                "\tend_ifIndex_field   %d\n"
				"\tcount               %d)\n"
			   	, val, chassisId_field,start_ifIndex_field,end_ifIndex_field, count);

	if( count )
    {
         mipIndex[mipIndexLength]=start_ifIndex_field;
         mipIndexLength++;
         mipIndex[mipIndexLength]=end_ifIndex_field;
         mipIndexLength++;
	}
	else {
//		pl_ret = plGetIfIndexFromSlotPort(slot, 0, (uint32*)&(mipIndex[0]));
//		CLI_CHECK_PL_RETURN(pl_ret, globals);
//		mipIndexLength = 1;
        SetFormatedDisplay(CliGetDisplayGlobals(globals), "ERROR: no ifIndex\n");
        globals->cliGlobals->error = 5;
        return ;
	}

	WRPset(globals, APPID_ESM_DRIVER, SNAPID_CMM_ESM_DRIVER_MIP);

	WRPwriteTable(globals, MIP_ESMCONFTABLE);
	WRPwriteIndex(globals, mipIndexLength, mipIndex);
  	WRPwriteObject(globals, mip_esmPortCfgMaxFrameSize, MIP_UINT32, 4, (uint8*)&val);

	WRPmip_msg_done(globals);
	WRPmip_free_buffer(globals);
}


void WRPesmInterfaceESMCONFTABLE(CliSubparserGlobals *globals, int obj, int val, int chassisId_field,
                                 int count, cliChassisSlotPort *slotport){

	MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
	int32		mipIndexLength=0;
//	pl_return_type pl_ret;
    int32       start_ifIndex_field,end_ifIndex_field;

	SetActionAllFamily(globals,  PM_FAMILY_INTERFACES, PARTM_EUP_AREA_PHYSICAL);
	// Set appid for config manager preparsing
	SetActionAppId(globals, APPID_ESM_DRIVER);
	WriteAction(globals);
	if (CliCheckAll(globals))
		return;

    start_ifIndex_field=slotport[0].startIfIndex;
    end_ifIndex_field=slotport[0].endIfIndex;

	if(CliDebugMip(globals))
		printf("WRPesmInterfaceESMCONFTABLE\n"
				"\tval                 %d\n"
				"\tchassisId_field     %d\n"
                "\tstart_ifIndex_field %d\n"
                "\tend_ifIndex_field   %d\n"
				"\tcount               %d)\n"
			   	, val, chassisId_field,start_ifIndex_field,end_ifIndex_field, count);

	if( count )
    {
         mipIndex[mipIndexLength]=start_ifIndex_field;
         mipIndexLength++;
         mipIndex[mipIndexLength]=end_ifIndex_field;
         mipIndexLength++;
	}
	else {
//		pl_ret = plGetIfIndexFromSlotPort(slot, 0, (uint32*)&(mipIndex[0]));
//		CLI_CHECK_PL_RETURN(pl_ret, globals);
//		mipIndexLength = 1;
        SetFormatedDisplay(CliGetDisplayGlobals(globals), "ERROR: no ifIndex\n");
        globals->cliGlobals->error = 5;
        return ;
	}

	WRPset(globals, APPID_ESM_DRIVER, SNAPID_CMM_ESM_DRIVER_MIP);

	WRPwriteTable(globals, MIP_ESMCONFTABLE);
	WRPwriteIndex(globals, mipIndexLength, mipIndex);
 	WRPwriteObject(globals, obj, MIP_UINT32, 4, (uint8*)&val);

	WRPmip_msg_done(globals);
	WRPmip_free_buffer(globals);
}


void WRPesmInterfaceESMPAUSETABLE(CliSubparserGlobals *globals, int obj, int val, int chassisId_field,
                                 int count, cliChassisSlotPort *slotport){

	MIP_OIDC 	mipIndex[CLI_MIP_IDX_LENGTH];
	int32		mipIndexLength=0;
//	pl_return_type pl_ret;
    int32       start_ifIndex_field,end_ifIndex_field;

	SetActionAllFamily(globals,  PM_FAMILY_INTERFACES, PARTM_EUP_AREA_PHYSICAL);
	// Set appid for config manager preparsing
	SetActionAppId(globals, APPID_ESM_DRIVER);
	WriteAction(globals);
	if (CliCheckAll(globals))
		return;

    start_ifIndex_field=slotport[0].startIfIndex;
    end_ifIndex_field=slotport[0].endIfIndex;

	if(CliDebugMip(globals))
		printf("WRPesmInterfaceESMPAUSETABLE\n"
				"\tval                 %d\n"
				"\tchassisId_field     %d\n"
                "\tstart_ifIndex_field %d\n"
                "\tend_ifIndex_field   %d\n"
				"\tcount               %d)\n"
			   	, val, chassisId_field,start_ifIndex_field,end_ifIndex_field, count);

	if( count )
    {
         mipIndex[mipIndexLength]=start_ifIndex_field;
         mipIndexLength++;
         mipIndex[mipIndexLength]=end_ifIndex_field;
         mipIndexLength++;
	}
	else {
//		pl_ret = plGetIfIndexFromSlotPort(slot, 0, (uint32*)&(mipIndex[0]));
//		CLI_CHECK_PL_RETURN(pl_ret, globals);
//		mipIndexLength = 1;
        SetFormatedDisplay(CliGetDisplayGlobals(globals), "ERROR: no ifIndex\n");
        globals->cliGlobals->error = 5;
        return ;
	}

	WRPset(globals, APPID_ESM_DRIVER, SNAPID_CMM_ESM_DRIVER_MIP);

	WRPwriteTable(globals, MIP_DOT3PAUSETABLE);
	WRPwriteIndex(globals, mipIndexLength, mipIndex);
 	WRPwriteObject(globals, obj, MIP_UINT32, 4, (uint8*)&val);

	WRPmip_msg_done(globals);
	WRPmip_free_buffer(globals);
}



void WRPesmInterfaceTypeSLOTFlood(CliSubparserGlobals *globals, int slot, int val){

	MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
	pl_return_type pl_ret;

	SetActionAllFamily(globals,  PM_FAMILY_INTERFACES, PARTM_EUP_AREA_PHYSICAL);
	// Set appid for config manager preparsing
	SetActionAppId(globals, APPID_ESM_DRIVER);
	WriteAction(globals);
	if (CliCheckAll(globals))
		return;

	if(CliDebugMip(globals))
		printf("WRPesmInterfaceTypeSLOTFlood(\n"
			"\tslot  %d\n"
			"\tval  %d\n"
			  , slot, val);

	WRPset(globals, APPID_ESM_DRIVER, SNAPID_CMM_ESM_DRIVER_MIP);
	WRPwriteTable(globals, MIP_ESMCONFTABLE);

	pl_ret = plGetIfIndexFromSlotPort(slot, 0, (uint32*)&(mipIndex[0]));
	CLI_CHECK_PL_RETURN(pl_ret, globals);
	WRPwriteIndex(globals, 1, mipIndex);
/* YP: Not needed in Rushmore
  WRPwriteObject(globals, mip_esmPortFloodMcastEnable, MIP_UINT32, 4, (uint8*)&val);
*/
	WRPmip_msg_done(globals);
	WRPmip_free_buffer(globals);
}


void WRPesmInterfaceTypeSLOTFloodMulticast(CliSubparserGlobals *globals, int slot, int val){

	MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
	pl_return_type pl_ret;

	SetActionAllFamily(globals,  PM_FAMILY_INTERFACES, PARTM_EUP_AREA_PHYSICAL);
	// Set appid for config manager preparsing
	SetActionAppId(globals, APPID_ESM_DRIVER);
	WriteAction(globals);
	if (CliCheckAll(globals))
		return;

	if(CliDebugMip(globals))
		printf("WRPesmInterfaceTypeSLOTFloodMulticast(\n"
			"\tslot  %d\n"
			"\tval  %d\n"
			  , slot, val);

	WRPset(globals, APPID_ESM_DRIVER, SNAPID_CMM_ESM_DRIVER_MIP);
	WRPwriteTable(globals, MIP_ESMCONFTABLE);

	pl_ret = plGetIfIndexFromSlotPort(slot, 0, (uint32*)&(mipIndex[0]));
	CLI_CHECK_PL_RETURN(pl_ret, globals);
	WRPwriteIndex(globals, 1, mipIndex);
/* YP: Not needed in Rushmore
 	WRPwriteObject(globals, mip_esmPortFloodMcastEnable, MIP_UINT32, 4, (uint8*)&val);
*/
	WRPmip_msg_done(globals);
	WRPmip_free_buffer(globals);
}

void WRPesmInterfaceTypeSLOTPORTAlias(CliSubparserGlobals *globals, char *str0, int start_ifIndex_field, int count, cliChassisSlotPort *slotport) {

	MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
	uint8    objValue[CLI_MAX_TOKEN_LENGTH];
	uint16   objLength;
//	pl_return_type pl_ret;
	int32 mipIndexLength=0;      
	int32 end_ifIndex_field,num;

	end_ifIndex_field=slotport[0].endIfIndex;
	SetActionAllFamily(globals,  PM_FAMILY_INTERFACES, PARTM_EUP_AREA_PHYSICAL);
	// Set appid for config manager preparsing
	SetActionAppId(globals, APPID_ESM_DRIVER);
	WriteAction(globals);
	if (CliCheckAll(globals))
		return;

	if(CliDebugMip(globals))
		printf("WRPesmInterfaceTypeSLOTPORTAlias(\n"
				"\tstr                 %s\n"
				"\tcount               %d\n"
                "\tstart_ifIndex_field %d)\n"
			   	, str0, count,start_ifIndex_field);
	objLength = strlen(str0);
	if(objLength > CLI_MAX_TOKEN_LENGTH){
		SetFormatedDisplay(CliGetDisplayGlobals(globals), "ERROR: Alias too long. Received length: %d. Max length: %d\n",
							objLength, CLI_MAX_TOKEN_LENGTH);
		globals->cliGlobals->error = 100;
		return;
	}
	WRPset(globals, APPID_ESM_DRIVER, SNAPID_CMM_ESM_DRIVER_MIP);
	WRPwriteTable(globals, MIP_IFXTABLE);

	if (count)
	{
		for(num=start_ifIndex_field; num<=end_ifIndex_field; num++)  
		{   
			mipIndex[mipIndexLength]=num;   
			if ( !mipIndex[mipIndexLength] || mipIndexLength > 50 ) {   
				SetFormatedDisplay(CliGetDisplayGlobals(globals), "ERROR: %s\n", ASCII_ERROR_SLOT_PORT);   
				globals->cliGlobals->error = 5;   
				return ;   
			}   
			mipIndexLength++;   
		} 
	}
	else
	{
//		pl_ret = plGetIfIndexFromSlotPort(slot, 0, (uint32*)&(mipIndex[0]));
//		CLI_CHECK_PL_RETURN(pl_ret, globals);
        SetFormatedDisplay(CliGetDisplayGlobals(globals), "ERROR: no ifIndex\n");
        globals->cliGlobals->error = 5;
        return ;
	}
	WRPwriteIndex(globals, mipIndexLength , mipIndex);

        memset(objValue,0,sizeof(objValue));
	memcpy((uint8*)objValue, str0, objLength);
  	WRPwriteObject(globals, mip_ifAlias, MIP_STRING, objLength, objValue);

	WRPmip_msg_done(globals);
	WRPmip_free_buffer(globals);
}


 void WRPesmDebugInterfacesHighPowerMode(CliSubparserGlobals *globals, int int0, int int1) {

         MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
         int32                mipIndexLength;
         int32     done, first;

         SetActionFuncFamily(globals,  PM_FAMILY_DEBUG);
	// Set appid for config manager preparsing
 	SetActionAppId(globals, APPID_ESM_DRIVER);
         WriteAction(globals);
         if (CliCheckAll(globals))
                 return;

         if(CliDebugMip(globals))
                 printf("WRPesmDebugInterfacesHighPowerMode(\n"
                                 "\tint  %d\n"
                                 "\tint  %d\n"
                                 , int0, int1);

         mipIndexLength = 3;

         if ( int0 == -1 && int1 == -1 ) {
                 mipIndex[0] = 1;
                 mipIndex[1] = 0;
                 mipIndex[2] = 0;
         }
         else if ( int1 == -1 ) {
                 mipIndex[0] = 0;
                 mipIndex[1] = int0;
                 mipIndex[2] = 0;
         }
         else {
                 mipIndex[0] = 0;
                 mipIndex[1] = int0;
                 mipIndex[2] = int1;
         }

         first = 1;

         do{
            WRPdebug(globals, APPID_ESM_DRIVER, SNAPID_CMM_ESM_DRIVER_MIP, first);
            first = 0;
            WRPmip_write_ascii_req(globals, 2, MIP_DEBUG_INTERFACES_HIGHPOWERMODE, mipIndexLength, mipIndex);
            done = WRPdone(globals, &mipIndexLength, mipIndex);
         }while(!done);
 }

 void WRPesmDebugInterfacesLowPowerMode(CliSubparserGlobals *globals, int int0, int int1) {

          MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
          int32                mipIndexLength;
          int32     done, first;

          SetActionFuncFamily(globals,  PM_FAMILY_DEBUG);
          WriteAction(globals);
          if (CliCheckAll(globals))
                  return;

          if(CliDebugMip(globals))
                  printf("WRPesmDebugInterfacesLowPowerMode(\n"
                                  "\tint  %d\n"
                                  "\tint  %d\n"
                                  , int0, int1);

          mipIndexLength = 3;

          if ( int0 == -1 && int1 == -1 ) {
                  mipIndex[0] = 1;
                  mipIndex[1] = 0;
                  mipIndex[2] = 0;
          }
         else if ( int1 == -1 ) {
                  mipIndex[0] = 0;
                  mipIndex[1] = int0;
                  mipIndex[2] = 0;
          }
         else {
                  mipIndex[0] = 0;
                  mipIndex[1] = int0;
                  mipIndex[2] = int1;
          }

          first = 1;

           do{
                  WRPdebug(globals, APPID_ESM_DRIVER, SNAPID_CMM_ESM_DRIVER_MIP, first);
             first = 0;
             WRPmip_write_ascii_req(globals, 2, MIP_DEBUG_INTERFACES_LOWPOWERMODE, mipIndexLength, mipIndex);
             done = WRPdone(globals, &mipIndexLength, mipIndex);
          }while(!done);
  }

void WRPesmDebugInterfacesXXX(CliSubparserGlobals *globals, int table, int int0, int int1) {

	MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
	int32		mipIndexLength;
	int32     done, first;

	SetActionFuncFamily(globals,  PM_FAMILY_DEBUG);
	WriteAction(globals);
	if (CliCheckAll(globals))
		return;

	if(CliDebugMip(globals))
		printf("WRPesmDebugInterfacesXXX(\n"
				"\tint0  %d\n"
				"\tint0  %d)\n"
			   	, int0, int1);

	mipIndexLength = 3;

	if ( int0 == -1 && int1 == -1 ) {
		mipIndex[0] = 1;
		mipIndex[1] = 0;
		mipIndex[2] = 0;
	}
	else if ( int1 == -1 ) {
		mipIndex[0] = 0;
		mipIndex[1] = int0;
		mipIndex[2] = 0;
	}
	else {
		mipIndex[0] = 0;
		mipIndex[1] = int0;
		mipIndex[2] = int1;
	}

	first = 1;

 	do{
		WRPdebug(globals, APPID_ESM_DRIVER, SNAPID_CMM_ESM_DRIVER_MIP, first);
   	first = 0;
   	WRPmip_write_ascii_req(globals, 2, table, mipIndexLength, mipIndex);
   	done = WRPdone(globals, &mipIndexLength, mipIndex);
	}while(!done);
}

void WRPdebugInterfacesLowLatency(CliSubparserGlobals *globals,int ifIndex_1_field,int ifIndex_2_field,int status_field)
{
    MIP_OIDC mipIndex[CLI_MIP_IDX_LENGTH];
    int32 mipIndexLength;
    int32 done,first;

    SetActionFuncFamily(globals,PM_FAMILY_DEBUG);

	// Set appid for config manager preparsing
	SetActionAppId(globals, APPID_ESM_DRIVER);

	WriteAction(globals);
	if (CliCheckAll(globals))
		return;

	if(CliDebugMip(globals))
		printf("WRPdebugInterfacesLowLatency(\n"
			   "\tint ifIndex_1_field %d\n"
			   "\tint ifIndex_2_field %d\n"
			   "\tint status_field    %d\n",
				ifIndex_1_field,ifIndex_2_field,status_field);

	mipIndexLength=3;

	mipIndex[0]=ifIndex_1_field;
	mipIndex[1]=ifIndex_2_field;
	mipIndex[2]=status_field;

	first=1;

	do
	{
		WRPdebug(globals,APPID_ESM_DRIVER,SNAPID_CMM_ESM_DRIVER_MIP,first);
		first=0;
		WRPmip_write_ascii_req(globals,MIP_ASCII_DEBUG,MIP_DEBUG_INTERFACES_SET_LOW_LATENCY,mipIndexLength,mipIndex);
		done=WRPdone(globals,&mipIndexLength,mipIndex);
	}while(!done);
}

void WRPdebugInterfacesShowLowLatency(CliSubparserGlobals *globals,int ifIndex_1_field,int ifIndex_2_field)
{
    MIP_OIDC mipIndex[CLI_MIP_IDX_LENGTH];
    int32 mipIndexLength;
    int32 done;
    int32 first;

    SetActionFuncFamily(globals,PM_FAMILY_DEBUG);
    WriteAction(globals);
    if(CliCheckAll(globals))
        return;

    if(CliDebugMip(globals))
		printf("WRPdebugInterfacesShowLowLatency(\n"
			   "\tint ifIndex_1_field %d\n"
			   "\tint ifIndex_2_field %d\n",
				ifIndex_1_field,ifIndex_2_field);

    mipIndexLength=2;
	mipIndex[0]=ifIndex_1_field;
	mipIndex[1]=ifIndex_2_field;

    first=1;

    do
	{
		WRPdebug(globals,APPID_ESM_DRIVER,SNAPID_CMM_ESM_DRIVER_MIP,first);
		first=0;
		WRPmip_write_ascii_req(globals,MIP_ASCII_DEBUG,MIP_DEBUG_INTERFACES_GET_LOW_LATENCY,mipIndexLength,mipIndex);
		done=WRPdone(globals,&mipIndexLength,mipIndex);
	}while(!done);
}

void WRPdebugInterfacesShow(CliSubparserGlobals *globals,int ifIndex_1_field,int ifIndex_2_field,int table_id)
{
    MIP_OIDC mipIndex[CLI_MIP_IDX_LENGTH];
    int32 mipIndexLength;
    int32 done;
    int32 first;

    SetActionFuncFamily(globals,PM_FAMILY_DEBUG);
    WriteAction(globals);
    if(CliCheckAll(globals))
        return;

    if(CliDebugMip(globals))
		printf("WRPdebugInterfacesShow(\n"
			   "\tint ifIndex_1_field %d\n"
			   "\tint ifIndex_2_field %d\n",
				ifIndex_1_field,ifIndex_2_field);

    mipIndexLength=2;
	mipIndex[0]=ifIndex_1_field;
	mipIndex[1]=ifIndex_2_field;

    first=1;

    do
	{
		WRPdebug(globals,APPID_ESM_DRIVER,SNAPID_CMM_ESM_DRIVER_MIP,first);
		first=0;
		WRPmip_write_ascii_req(globals,MIP_ASCII_DEBUG,table_id,mipIndexLength,mipIndex);
		done=WRPdone(globals,&mipIndexLength,mipIndex);
	}while(!done);
}

void WRPdebugInterfacesEnableDisable(CliSubparserGlobals *globals,int ifIndex_1_field,int ifIndex_2_field,int status_field,int table_id)
{
	MIP_OIDC mipIndex[CLI_MIP_IDX_LENGTH];
	int32 mipIndexLength;
	int32 done,first;

	SetActionFuncFamily(globals,PM_FAMILY_DEBUG);

	// Set appid for config manager preparsing
	SetActionAppId(globals, APPID_ESM_DRIVER);

	WriteAction(globals);
	if (CliCheckAll(globals))
		return;

	if(CliDebugMip(globals))
		printf("WRPdebugInterfacesEnableDisable(\n"
			"\tint ifIndex_1_field %d\n"
			"\tint ifIndex_2_field %d\n"
			"\tint status_field    %d\n"
			"\tint table_id        %d\n",
			ifIndex_1_field,ifIndex_2_field,status_field,table_id);

	mipIndexLength=3;

	mipIndex[0]=ifIndex_1_field;
	mipIndex[1]=ifIndex_2_field;
	mipIndex[2]=status_field;

	first=1;

	do
	{
		WRPdebug(globals,APPID_ESM_DRIVER,SNAPID_CMM_ESM_DRIVER_MIP,first);
		first=0;
		WRPmip_write_ascii_req(globals,MIP_ASCII_DEBUG,table_id,mipIndexLength,mipIndex);
		done=WRPdone(globals,&mipIndexLength,mipIndex);
	}while(!done);
}

void WRPdebugInterfacesFirmwareDownload(CliSubparserGlobals *globals,uint32 slot_field,char *filename_with_path)
{
	MIP_OIDC mipIndex[CLI_MIP_IDX_LENGTH];
	int32 mipIndexLength;
	int32 done,first,fname_len=0,i;

	SetActionFuncFamily(globals,PM_FAMILY_DEBUG);

	// Set appid for config manager preparsing
	SetActionAppId(globals, APPID_ESM_DRIVER);

	WriteAction(globals);
	if (CliCheckAll(globals))
		return;

	if(CliDebugMip(globals))
		printf("WRPdebugInterfacesFirmwareDownload(\n"
			"\tint    slot_field         %d\n"
			"\tstring filename_with_path %s\n",
			slot_field,filename_with_path);
 
	fname_len=strlen(filename_with_path);

	mipIndexLength=2+fname_len;

	mipIndex[0]=slot_field;
	mipIndex[1]=fname_len;

	for(i=0;i<fname_len;i++)
	{
		mipIndex[i+2]=filename_with_path[i];
	}

	first=1;

	do
	{
		WRPdebug(globals,APPID_ESM_DRIVER,SNAPID_CMM_ESM_DRIVER_MIP,first);
		first=0;
		WRPmip_write_ascii_req(globals,MIP_ASCII_DEBUG,MIP_DEBUG_INTERFACES_SET_PHY_FIRMWARE,mipIndexLength,mipIndex);
		done=WRPdone(globals,&mipIndexLength,mipIndex);
	}while(!done);
}

void WRPesmSetEnableDisable(CliSubparserGlobals *globals, int mibObject, int enable)
{
	SetActionFuncFamily(globals,  PM_FAMILY_INTERFACES);
	WriteAction(globals);

	if (CliCheckAll(globals))
		return;

	if(CliDebugMip(globals))
		printf("WRPesmSetEnableDisable(\n"
				"\tmibObject     %d\n"
				"\tenableDisable %d)\n"
				, mibObject, enable);

	WRPset(globals, APPID_ESM_DRIVER, SNAPID_CMM_ESM_DRIVER_MIP);

	WRPwriteTable(globals, MIP_DDMCONFIGURATION);
	WRPwriteIndex(globals, 0, NULL);
	WRPwriteObject(globals, mibObject, MIP_UINT32, 4, (uint8*)&enable);

	WRPmip_msg_done(globals);
	WRPmip_free_buffer(globals);
}

void WRPesmInterfaceTraffic(CliSubparserGlobals *globals, int type, int lim_val, int lim_type, int lim_enable, int burst, int chassisId_field, int count, cliChassisSlotPort *slotport,int lowval)
{
    MIP_OIDC		mipIndex[CLI_MIP_IDX_LENGTH];
    int32		mipIndexLength=0;
    //int32		num/*, startport, endport*/;
    int 		mip_enable = 0, mip_type = 0, mip_limit = 0, mip_burst = 0, mip_low = 0;
//    pl_return_type 	pl_ret;
    int32       start_ifIndex_field,end_ifIndex_field;

    SetActionAllFamily(globals,  PM_FAMILY_INTERFACES, PARTM_EUP_AREA_PHYSICAL);
    SetActionAppId(globals, APPID_ESM_DRIVER);
    WriteAction(globals);
    if (CliCheckAll(globals))
        return;

    if(CliDebugMip(globals))
        printf("WRPesmInterfaceTraffic\n"
                "\tinternal type   %d\n"
                "\tlim_val  %d\n"
                "\tlim_type  %d\n"
                "\tlim_enable  %d\n"
                "\tburst  %d\n"
                "\tchassisId_field %d\n"
                "\tport count %d)\n"
                "\tport lowval %d)\n"
                , type, lim_val, lim_type, lim_enable, burst, chassisId_field, count,lowval);
    switch (type)
    {
        case ESM_TYPE_BCAST:
            mip_enable = mip_esmPortBcastRateLimitEnable;
            mip_type = mip_esmPortBcastRateLimitType;
            mip_limit = mip_esmPortBcastRateLimit;
            mip_low = mip_esmPortMinBcastRateLimit;
            break;
        case ESM_TYPE_MCAST:
            mip_enable = mip_esmPortMcastRateLimitEnable;
            mip_type = mip_esmPortMcastRateLimitType;
            mip_limit = mip_esmPortMcastRateLimit;
            mip_low = mip_esmPortMinMcastRateLimit;
            break;
		case ESM_TYPE_UUCAST:
            mip_enable = mip_esmPortUucastRateLimitEnable;
            mip_type = mip_esmPortUucastRateLimitType;
            mip_limit = mip_esmPortUucastRateLimit;
            mip_low = mip_esmPortMinUucastRateLimit;
            break;
		case ESM_TYPE_INGRESS:
            mip_enable = mip_esmPortIngressRateLimitEnable;
            mip_limit = mip_esmPortIngressRateLimit;
            mip_burst = mip_esmPortIngressRateLimitBurst;
            break;
        default:
            printf("%s: invalid type %d\n", __func__, type);
    }

    start_ifIndex_field=slotport[0].startIfIndex;
    end_ifIndex_field=slotport[0].endIfIndex;

    if( count )
    {
        mipIndex[mipIndexLength]=start_ifIndex_field;
        mipIndexLength++;
        mipIndex[mipIndexLength]=end_ifIndex_field;
        mipIndexLength++;
    }
    else {
//        pl_ret = plGetIfIndexFromSlotPort(slot, 0, (uint32*)&(mipIndex[0]));
//        CLI_CHECK_PL_RETURN(pl_ret, globals);
//        mipIndexLength = 1;
        SetFormatedDisplay(CliGetDisplayGlobals(globals), "ERROR: no ifIndex\n");
        globals->cliGlobals->error = 5;
        return ;
    }

    WRPset(globals, APPID_ESM_DRIVER, SNAPID_CMM_ESM_DRIVER_MIP);

    WRPwriteTable(globals, MIP_ESMCONFTABLE);
    WRPwriteIndex(globals, mipIndexLength, mipIndex);
    if (lim_type == ESM_LIM_TYPE_ENADIS)
    {
 	    if (mip_enable != 0) WRPwriteObject(globals, mip_enable, MIP_UINT32, 4, (uint8*)&lim_enable);
    }
    else
    {
 	if (mip_type != 0) WRPwriteObject(globals, mip_type, MIP_UINT32, 4, (uint8*)&lim_type);
 	if (mip_limit != 0) WRPwriteObject(globals, mip_limit, MIP_UINT32, 4, (uint8*)&lim_val);
        if (type == ESM_TYPE_INGRESS)
        {
            if (mip_burst != 0) WRPwriteObject(globals, mip_burst, MIP_UINT32, 4, (uint8*)&burst);
        }
        if (lowval >= 0){
            if (mip_low != 0) WRPwriteObject(globals, mip_low, MIP_UINT32, 4, (uint8*)&lowval);
        }
    }

    WRPmip_msg_done(globals);
    WRPmip_free_buffer(globals);
}


void WRPesmInterfaceTypeSLOTPORTFloodAction(CliSubparserGlobals *globals, int type, int val,
		int chassisId_field, int count, cliChassisSlotPort *slotport) {

	MIP_OIDC		mipIndex[CLI_MIP_IDX_LENGTH];
	int32		mipIndexLength=0;
	//    int32		num/*, startport, endport*/;
	int32		start_ifIndex_field,end_ifIndex_field;

	SetActionAllFamily(globals,  PM_FAMILY_INTERFACES, PARTM_EUP_AREA_PHYSICAL);
	SetActionAppId(globals, APPID_ESM_DRIVER);
	WriteAction(globals);

	if (CliCheckAll(globals))
		return;

	if(CliDebugMip(globals))
		printf("WRPesmInterfaceTypeSLOTPORTFloodAction\n"
				"\tinternal type   %d\n"
				"\tchassisId_field %d\n"
				"\tport count %d)\n"
				"\val %d)\n"
				, type, chassisId_field, count,val);
	start_ifIndex_field=slotport[0].startIfIndex;
	end_ifIndex_field=slotport[0].endIfIndex;

	if( count )
	{
		mipIndex[mipIndexLength]=start_ifIndex_field;
		mipIndexLength++;
		mipIndex[mipIndexLength]=end_ifIndex_field;
		mipIndexLength++;
	}
	else {
		SetFormatedDisplay(CliGetDisplayGlobals(globals), "ERROR: no ifIndex\n");
		globals->cliGlobals->error = 5;
		return ;
	}

	WRPset(globals, APPID_ESM_DRIVER, SNAPID_CMM_ESM_DRIVER_MIP);

	WRPwriteTable(globals, MIP_ESMCONFTABLE);
	WRPwriteIndex(globals, mipIndexLength, mipIndex);

	switch (type)
	{
		case ESM_TYPE_BCAST:
			WRPwriteObject(globals, mip_esmPortBcastThresholdAction, MIP_UINT32, 4, (uint8*)&val);
			break;
		case ESM_TYPE_MCAST:
			WRPwriteObject(globals, mip_esmPortMcastThresholdAction, MIP_UINT32, 4, (uint8*)&val);
			break;
		case ESM_TYPE_UUCAST:
			WRPwriteObject(globals, mip_esmPortUucastThresholdAction, MIP_UINT32, 4, (uint8*)&val);
			break;
		default:
			SetFormatedDisplay(CliGetDisplayGlobals(globals), "Error: WRPesmInterfaceTypeSLOTPORTFloodAction received nonexistent type.");
			globals->cliGlobals->error = 100;
	}	

	WRPmip_msg_done(globals);
	WRPmip_free_buffer(globals);
}
void WRPesmInterfaceTdrState(CliSubparserGlobals *globals, uint32 start_ifIndex_field, uint32 end_ifIndex_field, int state_field)
{
    MIP_OIDC            mipIndex[CLI_MIP_IDX_LENGTH];
    int32           mipIndexLength=0;

        SetActionFuncFamily(globals,  PM_FAMILY_INTERFACES);
        WriteAction(globals);

        if (CliCheckAll(globals))
                return;

        if(CliDebugMip(globals))
                printf("WRPesmInterfaceState(\n"
                                "\tstart_ifIndex_field     %d\n"
                                "\tend_ifIndex_field       %d\n"
                "\tstate_field             %d)\n"
                                , start_ifIndex_field, end_ifIndex_field, state_field);

    mipIndex[0]=start_ifIndex_field;
    mipIndexLength=1;

        WRPset(globals, APPID_ESM_DRIVER, SNAPID_CMM_ESM_DRIVER_MIP);

        WRPwriteTable(globals, MIP_ESMTDRPORTTABLE);
        WRPwriteIndex(globals, mipIndexLength, mipIndex);
        WRPwriteObject(globals, mip_esmTdrPortTest, MIP_UINT32, 4, (uint8*)&state_field);


        WRPmip_msg_done(globals);
        WRPmip_free_buffer(globals);
}

void WRPesmInterfaceClearTdrStatistics(CliSubparserGlobals *globals, uint32 start_ifIndex_field, uint32 end_ifIndex_field)
{
    MIP_OIDC            mipIndex[CLI_MIP_IDX_LENGTH];
    int32           mipIndexLength=0;
    int             clear_stats=2;

        SetActionFuncFamily(globals,  PM_FAMILY_INTERFACES);
        WriteAction(globals);

        if (CliCheckAll(globals))
                return;

        if(CliDebugMip(globals))
                printf("WRPesmInterfaceState(\n"
                                "\tstart_ifIndex_field     %d\n"
                                "\tend_ifIndex_field       %d\n"
                "\tclear_stats             %d)\n"
                                , start_ifIndex_field, end_ifIndex_field, clear_stats);

    mipIndex[0]=start_ifIndex_field;
    mipIndex[1]=end_ifIndex_field;
    mipIndexLength=2;

        WRPset(globals, APPID_ESM_DRIVER, SNAPID_CMM_ESM_DRIVER_MIP);

        WRPwriteTable(globals, MIP_ESMTDRPORTTABLE);
        WRPwriteIndex(globals, mipIndexLength, mipIndex);
        WRPwriteObject(globals, mip_esmTdrPortClearStats, MIP_UINT32, 4, (uint8*)&clear_stats);


        WRPmip_msg_done(globals);
        WRPmip_free_buffer(globals);
}

void WRPesmPmClearSLOTPORT(CliSubparserGlobals *globals, int ndx1, int ndx2)
{
	MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
	int32		mipIndexLength = 0;
	int 		int1 = 1;

	SetActionFuncFamily(globals, PM_FAMILY_INTERFACES);
	SetActionAppId(globals,  APPID_PORT_MANAGER);
	WriteAction(globals);
	if (CliCheckAll(globals))
		return;

	if(CliDebugMip(globals))
		printf("WRPesmPmClearSLOTPORT("
			"\tindex1  %d\n"
			"\tindex2  %d)\n",
			ndx1, ndx2);

	WRPset(globals,  APPID_PORT_MANAGER, SNAPID_PORT_MANAGER_MIP);
	WRPwriteTable(globals, MIP_PORTVIOLATIONTABLE);

	mipIndex[mipIndexLength] = ndx1;
	mipIndexLength++;
	mipIndex[mipIndexLength] = ndx2;
	mipIndexLength++;

	WRPwriteIndex(globals, mipIndexLength, mipIndex);

	WRPwriteObject(globals, mip_portViolationClearPort, MIP_UINT32, 4, (uint8*)&int1);

	WRPmip_msg_done(globals);
	WRPmip_free_buffer(globals);
}

void WRPesmShowPm(CliSubparserGlobals *globals, int ndx1, int ndx2, int table)
{
	MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
	int32		mipIndexLength = 0;
	int32     done;

	SetActionFuncFamily(globals,  PM_FAMILY_INTERFACES);
	ReadAction(globals);
	if (CliCheckAll(globals))
		return;

	if(ndx1 == -1 && ndx2 == -1 && table == MIP_DISP_PM_PVR_GLOBAL_CFG)
        {
                ndx1 = 0;
                ndx2 = 0;
        }
	
	if(CliDebugMip(globals))
		printf("WRPesmShowPm()\n"
			"\tindex1  %d\n"
			"\tindex2  %d\n"
			"\ttable   %d)\n",
			ndx1, ndx2, table);

	mipIndex[mipIndexLength] = ndx1;
	mipIndexLength++;
	mipIndex[mipIndexLength] = ndx2;
	mipIndexLength++;

	do{
		WRPshow(globals, APPID_PORT_MANAGER, SNAPID_PORT_MANAGER_MIP);
		WRPmip_write_ascii_req(globals, 1, table, mipIndexLength, mipIndex);
		done = WRPdone(globals, &mipIndexLength, mipIndex);
	} while(!done);
}

void WRPesmInterfaceTypeSLOTPORTLinkMonConfig(CliSubparserGlobals *globals, int val,
		int chassisId_field, 
		int count, cliChassisSlotPort *slotport,MIP_OBJ_TYPE objType) {
    MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
    int32		mipIndexLength=0;
    int32     num/*, startport, endport*/;
    int32       start_ifIndex_field,end_ifIndex_field;

    SetActionFuncFamily(globals, PM_FAMILY_INTERFACES);
    SetActionAppId(globals, APPID_PORT_MANAGER);
    WriteAction(globals);
    if (CliCheckAll(globals))
        return;
    start_ifIndex_field=slotport[0].startIfIndex;
    end_ifIndex_field=slotport[0].endIfIndex;
    if(CliDebugMip(globals))
        printf("WRPesmInterfaceTypeSLOTPORTLinkMonConfig(\n"
                "\tval                 %d\n"
                "\tchassisId_field     %d\n"
                "\tstart_ifIndex_field %d\n"
                "\tend_ifIndex_field   %d\n"
                "\tcount               %d)\n"
                , val, chassisId_field,start_ifIndex_field,end_ifIndex_field, count);
    if( count ) 
    {
        for(num=start_ifIndex_field; num<=end_ifIndex_field; num++)
        {
            mipIndex[mipIndexLength]=num;
            if ( !mipIndex[mipIndexLength] || mipIndexLength >= CLI_MIP_IDX_LENGTH ) {
                SetFormatedDisplay(CliGetDisplayGlobals(globals), "ERROR: %s\n", ASCII_ERROR_SLOT_PORT);
                globals->cliGlobals->error = 5;
                return ;
            }
            mipIndexLength++;
        }
    }
    else 
    {
        SetFormatedDisplay(CliGetDisplayGlobals(globals), "ERROR: no ifIndex\n");
        globals->cliGlobals->error = 5;
        return ;
    }
    WRPset(globals, APPID_PORT_MANAGER, SNAPID_PORT_MANAGER_MIP);     
    WRPwriteTable(globals, MIP_ALALINKMONCONFIGTABLE);
    WRPwriteIndex(globals, mipIndexLength, mipIndex);
    WRPwriteObject(globals, (uint8)objType, MIP_UINT32, 4, (uint8*)&val);
    WRPmip_msg_done(globals);
    WRPmip_free_buffer(globals);
}

void WRPesmInterfaceTypeSLOTPORTLinkMonStats(CliSubparserGlobals *globals, int val,
		int chassisId_field, 
		int count, cliChassisSlotPort *slotport,MIP_OBJ_TYPE objType) {
    MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
    int32		mipIndexLength=0;
    int32     num/*, startport, endport*/;
    int32       start_ifIndex_field,end_ifIndex_field;
    SetActionFuncFamily(globals, PM_FAMILY_INTERFACES);
    SetActionAppId(globals, APPID_PORT_MANAGER);
    WriteAction(globals);
    if (CliCheckAll(globals))
        return;
    start_ifIndex_field=slotport[0].startIfIndex;
    end_ifIndex_field=slotport[0].endIfIndex;
    if(CliDebugMip(globals))
        printf("WRPesmInterfaceTypeSLOTPORTLinkMonStats(\n"
                "\tval                 %d\n"
                "\tchassisId_field     %d\n"
                "\tstart_ifIndex_field %d\n"
                "\tend_ifIndex_field   %d\n"
                "\tcount               %d)\n"
                , val, chassisId_field,start_ifIndex_field,end_ifIndex_field, count);
    if( count ) 
    {
        for(num=start_ifIndex_field; num<=end_ifIndex_field; num++)
        {
            mipIndex[mipIndexLength]=num;
            if ( !mipIndex[mipIndexLength] || mipIndexLength >=CLI_MIP_IDX_LENGTH  ) {
                SetFormatedDisplay(CliGetDisplayGlobals(globals), "ERROR: %s\n", ASCII_ERROR_SLOT_PORT);
                globals->cliGlobals->error = 5;
                return ;
            }
            mipIndexLength++;
        }
    }
    else 
    {
        SetFormatedDisplay(CliGetDisplayGlobals(globals), "ERROR: no ifIndex\n");
        globals->cliGlobals->error = 5;
        return ;
    }
    WRPset(globals, APPID_PORT_MANAGER, SNAPID_PORT_MANAGER_MIP);     
    WRPwriteTable(globals, MIP_ALALINKMONSTATSTABLE);
    WRPwriteIndex(globals, mipIndexLength, mipIndex);
    WRPwriteObject(globals, mip_alaLinkMonStatsClearStats, MIP_UINT32, 4, (uint8*)&val); 
    WRPmip_msg_done(globals);
    WRPmip_free_buffer(globals);
}

void WRPesmLFPCreateGroup(CliSubparserGlobals *globals, int groupId)
{
    MIP_OIDC   mipIndex[CLI_MIP_IDX_LENGTH];
    int32      mipIndexLength;
    int32      val =4;
    SetActionAllFamily(globals,  PM_FAMILY_INTERFACES, PARTM_EUP_AREA_PHYSICAL);
    WriteAction(globals);
    if(CliCheckAll(globals))
        return;
    if ( CliDebugMip(globals))
    {
        printf("WRPEsmLFPCreatGroup:\n"
                "\t GroupId      = %d\n", groupId);
    }
    WRPset(globals, APPID_PORT_MANAGER, SNAPID_PORT_MANAGER_MIP);
    mipIndexLength = 1;
    mipIndex[0] = groupId;
    WRPwriteTable(globals,MIP_ALALFPGROUPTABLE); 
    WRPwriteIndex(globals, mipIndexLength, mipIndex);
    WRPwriteObject(globals, mip_alaLFPGroupRowStatus, MIP_INT32, 4, (uint8*)&val);
    WRPmip_msg_done(globals);
    WRPmip_free_buffer(globals);
}

void WRPesmLFPConfigGroup(CliSubparserGlobals *globals, int groupId, int status, int timer)
{
    MIP_OIDC   mipIndex[CLI_MIP_IDX_LENGTH];
    int32	   mipIndexLength=0;
    SetActionAllFamily(globals,  PM_FAMILY_INTERFACES, PARTM_EUP_AREA_PHYSICAL);
    WriteAction(globals);
    if(CliCheckAll(globals))
        return;
    if ( CliDebugMip(globals))
    {
        printf("WRPEsmLFPCreatGroup:\n "
                "\t GroupId          = %d\n"
                "\t Admin status     = %d\n"
                "\t WTS Timer        = %d\n", groupId, status, timer);
    }
    WRPset(globals, APPID_PORT_MANAGER, SNAPID_PORT_MANAGER_MIP);
    mipIndexLength = 1;
    mipIndex[0] = groupId;
    WRPwriteTable(globals,MIP_ALALFPGROUPTABLE); 	
    WRPwriteIndex(globals, mipIndexLength, mipIndex);
    if(status != -1)
    {
#if 0
        if(status == 2)  
            status = 0; //LFP_DISABLE
        else
            status = 1; //LFP_ENABLE
#endif
        WRPwriteObject(globals, mip_alaLFPGroupAdminStatus, MIP_INT32, 4, (uint8*)&status);
    }
    if(timer !=  -1)
        WRPwriteObject(globals, mip_alaLFPGroupWaitToShutdown, MIP_INT32, 4, (uint8*)&timer);
    WRPmip_msg_done(globals);
    WRPmip_free_buffer(globals);
}

int32 	pmFindIfIndex(int32 indextype, int32 slotnum, int32 daught,	int32 portorins){
    if ( indextype == ETH_IDX_TYPE )
        return (slotnum*1000 + portorins);
    else if ( indextype == LINKAGG_IDX_TYPE)
        return (portorins+40000000);
    return 0;
}

void WRPesmLFPPortConfig(CliSubparserGlobals *globals, int groupId,   int status,
        cliChassisSlotPort *portRange, LFP_PORT_INFO *phyPortType, int portRangeNum,
        aggRange    *aggRange,  LFP_PORT_INFO *aggPortType, int aggRangeNum)
{
    MIP_OIDC   mipIndex[CLI_MIP_IDX_LENGTH];
    int32      mipIndexLength=0;
    int32      portType = 0;
    int32      num = 0, num1=0, start = 0, end= 0, slot = 0;

    SetActionAllFamily(globals,  PM_FAMILY_INTERFACES, PARTM_EUP_AREA_PHYSICAL);
    WriteAction(globals);
    if(CliCheckAll(globals))
        return;
    if( !portRangeNum && !aggRangeNum )
    {
        if ( CliDebugMip(globals))
            printf(" WRPEsmLFPPortConfig(): Port/LinkAgg are NULL"); 
        return;
    }
    if ( CliDebugMip(globals))
    {
        printf(" WRPEsmLFPPortConfig:\n"
                "\tgroupId      = %d \n"
                "\tRow status   = %d\n"
                "\tportRangeNum = %d\n"
                "\taggRangeNum  = %d\n", groupId, status, portRangeNum, aggRangeNum);
        for(num=0; num<portRangeNum; num++)
        {
            printf("\tportType     = %d\n"
                    "\t\t chassis = %d\tSlot = %d\t StartPort = %d\t EndPort = %d\n",
                    phyPortType[num], portRange[num].chassisId, portRange[num].slot, portRange[num].startPort,
                    portRange[num].endPort);
        }
        for(num=0; num<aggRangeNum; num++)
        {
            printf("\tportType     = %d\n"
                    "\t\tStartAggId = %d\t EndAggId  = %d\n",
                    aggPortType[num], aggRange[num].aggId1, aggRange[num].aggId2);
        }	
    }
    for (num=0; num<portRangeNum; num++)
    {
        mipIndexLength = 1;
        mipIndex[mipIndexLength-1] = groupId;
        slot     = portRange[num].slot;
        start    = portRange[num].startIfIndex;
        end = start;
        if(portRange[num].endIfIndex)
            end      = portRange[num].endIfIndex;
        portType = phyPortType[num];
        for(num1=start; num1<=end; num1++)
        {
            mipIndexLength++;
            mipIndex[mipIndexLength-1]=num1;
            if (mipIndexLength >= CLI_MIP_IDX_LENGTH  ) 
            {
                globals->cliGlobals->error = 5;
		SetFormatedDisplay(CliGetDisplayGlobals(globals), "ERROR: %s\n", "Invalid range");
                 
                WRPmip_free_buffer(globals);
                return ;
            }}	
            WRPset(globals, APPID_PORT_MANAGER, SNAPID_PORT_MANAGER_MIP);
            WRPwriteTable(globals, MIP_ALALFPCONFIGTABLE);
            WRPwriteIndex(globals, mipIndexLength, mipIndex);
            WRPwriteObject(globals, mip_alaLFPConfigPortType, MIP_INT32, 4, (uint8*)&portType);
            WRPwriteObject(globals, mip_alaLFPConfigRowStatus, MIP_INT32, 4, (uint8*)&status);
            WRPmip_msg_done(globals);
            WRPmip_free_buffer(globals);
    }
    for (num=0; num<aggRangeNum; num++)
    {
        mipIndexLength = 1;
        mipIndex[mipIndexLength-1] = groupId;
        slot     = 0;
        start    = aggRange[num].aggId1;
        end      = aggRange[num].aggId2;
        portType = aggPortType[num];
        for(num1=start; num1<=end; num1++)
        {
            mipIndexLength++;
            mipIndex[mipIndexLength-1] = pmFindIfIndex(LINKAGG_IDX_TYPE, 0, 0, num1);
            if (mipIndexLength > 65 ) 
            {
                globals->cliGlobals->error = 5;
		SetFormatedDisplay(CliGetDisplayGlobals(globals), "ERROR: %s\n", "Invalid link agg range");
                WRPmip_free_buffer(globals);
                return ;
            }
        }
        WRPset(globals, APPID_PORT_MANAGER, SNAPID_PORT_MANAGER_MIP);
        WRPwriteTable(globals, MIP_ALALFPCONFIGTABLE);
        WRPwriteIndex(globals, mipIndexLength, mipIndex);
        WRPwriteObject(globals, mip_alaLFPConfigPortType, MIP_INT32, 4, (uint8*)&portType);
        WRPwriteObject(globals, mip_alaLFPConfigRowStatus, MIP_INT32, 4, (uint8*)&status);
        WRPmip_msg_done(globals);
        WRPmip_free_buffer(globals);
    }
}

void WRPesmShowLFPGroupConfig(CliSubparserGlobals *globals, int option)
{
    MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
    int32       mipIndexLength =0 ;
    int32       done, table = 0;
    SetActionFuncFamily(globals,  PM_FAMILY_CHASSIS);
    WriteAction(globals);
    if (CliCheckAll(globals))
        return;
    if(CliDebugMip(globals))
        printf("WRPesmShowLFPGroupConfig()\n \tGroupId  = %d \n", option);
    if(option != -1)
    {
        mipIndex[0] = option;
        mipIndexLength++;
        table = MIP_DISP_INTERFACES_LFP_CONFIG;
    }
    else
        table = MIP_DISP_INTERFACES_LFP_ALL_CONFIG;
    do
    {
        WRPshow(globals,  APPID_PORT_MANAGER, SNAPID_PORT_MANAGER_MIP);
        WRPmip_write_ascii_req(globals, 1, table, mipIndexLength, mipIndex);
        done = WRPdone(globals, &mipIndexLength, mipIndex);
    }while(!done);
}

void WRPesmLFPDeleteGroup(CliSubparserGlobals *globals, int groupId1, int groupId2)
{
	MIP_OIDC  mipIndex[CLI_MIP_IDX_LENGTH];
	int32     mipIndexLength=0;
	int32     val = 6;
	SetActionAllFamily(globals,  PM_FAMILY_INTERFACES, PARTM_EUP_AREA_PHYSICAL);
	WriteAction(globals);
	if (CliCheckAll(globals))
		return;
	if (CliDebugMip(globals))
	{
		printf("WRPEsmLFPCreatGroup:\n "
				"\t GroupId1     = %d\n"
				"\t GroupId2     = %d\n", groupId1,groupId2);
	}
	WRPset(globals, APPID_PORT_MANAGER, SNAPID_PORT_MANAGER_MIP);
	if((groupId1 != -1) && (groupId2 != -1))
	{
		mipIndexLength = 2;
		mipIndex[0]    = groupId1;
		mipIndex[1]    = groupId2;
	}
	else if(groupId1 != -1)
	{
		mipIndexLength = 1;
		mipIndex[0]    = groupId1;
	}
	WRPwriteTable(globals, MIP_ALALFPGROUPTABLE);
	WRPwriteIndex(globals, mipIndexLength, mipIndex);
	WRPwriteObject(globals, mip_alaLFPGroupRowStatus, MIP_INT32, 4, (uint8*)&val);
	WRPmip_msg_done(globals);
	WRPmip_free_buffer(globals);
}

void WRPpmShowInterfacesXXX(CliSubparserGlobals *globals, int table, int type,
    int start_ifIndex_field, int end_ifIndex_field,
    int count, cliChassisSlotPort *slotport) 
{

	MIP_OIDC		mipIndex[CLI_MIP_IDX_LENGTH] =  { '\0' };
	int32		mipIndexLength=0;
	int32		done;

	SetActionAllFamily(globals,  PM_FAMILY_INTERFACES, PARTM_EUP_AREA_PHYSICAL);
	ReadAction(globals);
	if (CliCheckAll(globals))
		return;
	if(CliDebugMip(globals))
		printf("WRPpmShowInterfacesXXX(\n"
				"\ttable                  %d\n"
				"\ttype                   %d\n"
				"\tstart_ifIndex_field    %d\n"
				"\tend_ifIndex_field      %d\n"
				"\tcount                  %d)\n"
				, table, type, start_ifIndex_field, end_ifIndex_field, count);

	mipIndex[0] = type;
	if (count)
	{
		mipIndex[1] = start_ifIndex_field;
		mipIndex[2] = end_ifIndex_field;
		mipIndexLength=3;
	}
	else
	{
		mipIndex[1]=0;
		mipIndexLength=2;
	}
	do{
		WRPshow(globals, APPID_PORT_MANAGER, SNAPID_PORT_MANAGER_MIP);	
		if (!mipIndex[1])
			WRPmip_write_ascii_all(globals, MIP_ALL);
		WRPmip_write_ascii_req(globals, 1, table, mipIndexLength, mipIndex);
		done = WRPdone(globals, &mipIndexLength, mipIndex);
	}while(!done);
}


void WRPpmInterfaceESMCONFTABLE(CliSubparserGlobals *globals, int obj, int val, int slot,
        int count, cliChassisSlotPort *slotport){
    MIP_OIDC 	mipIndex[CLI_MIP_IDX_LENGTH];
    int32		mipIndexLength=0;
    int32		num, startport, endport;
    SetActionAllFamily(globals,  PM_FAMILY_INTERFACES, PARTM_EUP_AREA_PHYSICAL);
    WriteAction(globals);
    if (CliCheckAll(globals))
        return;
    if(CliDebugMip(globals))
        printf("WRPesmInterfaceESMCONFTABLE\n"
                "\tval   %d\n"
                "\tslot  %d\n"
                "\tcount %d)\n"
                , val, slot, count);
    if( count ) {
        startport = slotport[0].startPort;
        endport	= slotport[0].endPort;
        for(num=startport; num<=endport; num++) {
            mipIndex[mipIndexLength] = pmFindIfIndex(ETH_IDX_TYPE, slotport[0].slot, 0, num);
            {
                SetFormatedDisplay(CliGetDisplayGlobals(globals), "ERROR: %s\n", ASCII_ERROR_HYBRID_PORT);
                globals->cliGlobals->error = 100;
                return;
            }
            if ( !mipIndex[mipIndexLength] || mipIndexLength > 50 ) {
                SetFormatedDisplay(CliGetDisplayGlobals(globals), "ERROR: %s\n", ASCII_ERROR_SLOT_PORT);
                globals->cliGlobals->error = 5;
                return ;
            }
            mipIndexLength++;
        }
    }
    else {
        mipIndex[0] = pmFindIfIndex(ETH_IDX_TYPE, slot, 0, 0);
        mipIndexLength = 1;
    }
    WRPset(globals, APPID_PORT_MANAGER, SNAPID_PORT_MANAGER_MIP);
    WRPwriteTable(globals, MIP_PORTVIOLATIONTABLE);
    WRPwriteIndex(globals, mipIndexLength, mipIndex);
    WRPwriteObject(globals, obj, MIP_UINT32, 4, (uint8*)&val);
    WRPmip_msg_done(globals);
    WRPmip_free_buffer(globals);
}

void WRPesmViolationGlobalAutoRecovery(CliSubparserGlobals *globals, int val, int violationType)
{
        MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
        int32       mipIndexLength = 0;

        SetActionFuncFamily(globals, PM_FAMILY_PORT_MANAGER);
        SetActionAppId(globals,  APPID_PORT_MANAGER);
        WriteAction(globals);
        if (CliCheckAll(globals))
                return;

        if(CliDebugMip(globals))
                printf("WRPesmViolationGlobalAutoRecovery(\n"
                        "\tvalue  %d\n"
                        "\ttype   %s)\n",
                        val, (violationType == 0) ? "Maximum": "Time");

        if(violationType == 0 && val != -1 && (val < 0 || val > 50) ) //neg value (infinite) can only come from EsmReduce.c
        {
                SetFormatedDisplay(CliGetDisplayGlobals(globals),"ERROR: Maximum recovery should be in the range 0-50.");
                globals->cliGlobals->error=CLI_EXIT;
                return;
        }
        else if(violationType == 1 && (val < 30 || val > 600) )
        {
                SetFormatedDisplay(CliGetDisplayGlobals(globals),"ERROR: Retry time should be in the range 30-600.");
                globals->cliGlobals->error=CLI_EXIT;
                return;
        }


        WRPset(globals,  APPID_PORT_MANAGER, SNAPID_PORT_MANAGER_MIP);
        WRPwriteTable(globals, MIP_ALAPVRGLOBALCONFIGOBJECTS);

        mipIndex[mipIndexLength] = 0;
        mipIndexLength++;
        mipIndex[mipIndexLength] = 0;
        mipIndexLength++;

        WRPwriteIndex(globals, mipIndexLength, mipIndex);

        if(violationType == 0)
                WRPwriteObject(globals, mip_alaPvrGlobalRecoveryMax, MIP_INT32, 4, (uint8*)&val);
        else if(violationType == 1)
                WRPwriteObject(globals, mip_alaPvrGlobalRetryTime, MIP_INT32, 4, (uint8*)&val);

        WRPmip_msg_done(globals);
        WRPmip_free_buffer(globals);
}


void WRPesmViolationAutoRecovery(CliSubparserGlobals *globals, int start_ifIndex_field, int end_ifIndex_field, int val, int violationType)
{
        MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
        int32       mipIndexLength=0;

        SetActionFuncFamily(globals, PM_FAMILY_PORT_MANAGER);
        SetActionAppId(globals,  APPID_PORT_MANAGER);
        WriteAction(globals);

        if (CliCheckAll(globals))
                return;

        if(start_ifIndex_field == -1 && end_ifIndex_field == -1)
        {
                start_ifIndex_field = 0;
                end_ifIndex_field = 0;
        }

        if(CliDebugMip(globals))
                printf("WRPesmViolationAutoRecovery(\n"
                                "\tvalue                  %d\n"
                                "\tstart_ifIndex_field    %d\n"
                                "\tend_ifIndex_field      %d\n"
                                "\ttype                   %s)\n"
                                , val, start_ifIndex_field, end_ifIndex_field, (violationType == 0) ? "Maximum": "Time");

        if(violationType == 0 && val != -1 &&  val != -2 && (val < 0 || val > 50) ) //neg value (infinite/default) can only come from EsmReduce.c
        {
                SetFormatedDisplay(CliGetDisplayGlobals(globals),"ERROR: Maximum recovery should be in the range 1-50.");
                globals->cliGlobals->error=CLI_EXIT;
                return;
        }
        else if(violationType == 1 && val != -2 && (val < 30 || val > 600) ) //neg value (default) can only come from EsmReduce.c
        {
                SetFormatedDisplay(CliGetDisplayGlobals(globals),"ERROR: Retry time should be in the range 30-600.");
                globals->cliGlobals->error=CLI_EXIT;
                return;
        }

        mipIndex[mipIndexLength]=start_ifIndex_field;
        mipIndexLength++;
        mipIndex[mipIndexLength]=end_ifIndex_field;
        mipIndexLength++;

        WRPset(globals,  APPID_PORT_MANAGER, SNAPID_PORT_MANAGER_MIP);
        WRPwriteTable(globals, MIP_ALAPVRCONFIGTABLE);
        WRPwriteIndex(globals, mipIndexLength, mipIndex);

        if(violationType == 0)
                WRPwriteObject(globals, mip_alaPvrRecoveryMax, MIP_INT32, 4, (uint8*)&val);
        else if(violationType == 1)
                WRPwriteObject(globals, mip_alaPvrRetryTime, MIP_INT32, 4, (uint8*)&val);

        WRPmip_msg_done(globals);
        WRPmip_free_buffer(globals);
}

void WRPesmSetViolationEnableDisable(CliSubparserGlobals *globals, int enable)
{
	MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
        int32       mipIndexLength = 0;

        SetActionFuncFamily(globals,  PM_FAMILY_PORT_MANAGER);
        WriteAction(globals);

	if (CliCheckAll(globals))
		return;

	if(CliDebugMip(globals))
		printf("WRPesmSetViolationEnableDisable(\n"
				"\tEnableDisable %d)\n"
				, enable);

        WRPset(globals, APPID_PORT_MANAGER, SNAPID_PORT_MANAGER_MIP);
        WRPwriteTable(globals, MIP_ALAPVRGLOBALCONFIGOBJECTS);
	
	mipIndex[mipIndexLength] = 0;
        mipIndexLength++;
        mipIndex[mipIndexLength] = 0;
        mipIndexLength++;

        WRPwriteIndex(globals, mipIndexLength, mipIndex);
        WRPwriteObject(globals, mip_alaPvrGlobalTrapEnable, MIP_UINT32, 4, (uint8*)&enable);

	WRPmip_msg_done(globals);
	WRPmip_free_buffer(globals);
}

void WRPesmInterfaceIfgSet(CliSubparserGlobals *globals,int val_field,int chassisId_field,int count_field,cliChassisSlotPort *slot_port)
{
    MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
    int32       mipIndexLength=0;
    int32     num/*, startport, endport*/;
//  pl_return_type pl_ret;
    int32       start_ifIndex_field,end_ifIndex_field;

    SetActionAllFamily(globals,  PM_FAMILY_INTERFACES, PARTM_EUP_AREA_PHYSICAL);
    // Set appid for config manager preparsing
    SetActionAppId(globals, APPID_ESM_DRIVER);
    WriteAction(globals);
    if (CliCheckAll(globals))
        return;

    start_ifIndex_field=slot_port[0].startIfIndex;
    end_ifIndex_field=slot_port[0].endIfIndex;

    if(CliDebugMip(globals))
        printf("WRPesmInterfaceIfgSet(\n"
            "\tval_field            %d\n"
            "\tchassisId_field      %d\n"
            "\tstart_ifIndex_field  %d\n"
            "\tend_ifIndex_field    %d\n"
            "\tcount_field          %d)\n",
            val_field,chassisId_field,start_ifIndex_field,end_ifIndex_field,count_field);

    if(count_field)
    {
//      startport = slot_port[0].startPort;
//      endport = slot_port[0].endPort;
        for(num=start_ifIndex_field; num<=end_ifIndex_field; num++)
        {
//          pl_ret = plGetIfIndexFromSlotPort(slot_port[0].slot, num, (uint32*)&(mipIndex[mipIndexLength]));
//          CLI_CHECK_PL_RETURN(pl_ret, globals);
            mipIndex[mipIndexLength]=num;
            if ( !mipIndex[mipIndexLength] || mipIndexLength > 50 )
            {
                SetFormatedDisplay(CliGetDisplayGlobals(globals), "ERROR: %s\n", ASCII_ERROR_SLOT_PORT);
                globals->cliGlobals->error = 5;
                return ;
            }
            mipIndexLength++;
        }
    }
    else
    {
//      pl_ret = plGetIfIndexFromSlotPort(slot_field, 0, (uint32*)&(mipIndex[0]));
//      CLI_CHECK_PL_RETURN(pl_ret, globals);
//      mipIndexLength = 1;
        SetFormatedDisplay(CliGetDisplayGlobals(globals), "ERROR: no ifIndex\n");

        globals->cliGlobals->error = 5;
        return ;
    }

    WRPset(globals, APPID_ESM_DRIVER, SNAPID_CMM_ESM_DRIVER_MIP);

    WRPwriteTable(globals, MIP_ESMCONFTABLE);
    WRPwriteIndex(globals, mipIndexLength, mipIndex);
    WRPwriteObject(globals,mip_esmPortIfg,MIP_UINT32,4,(uint8 *)&val_field);

    WRPmip_msg_done(globals);
    WRPmip_free_buffer(globals);
}

void WRPesmPtPConfig(CliSubparserGlobals *globals, EsmObjectList *EsmList,
                    int32 objCount)
{
    int32    onum;

    SetActionFuncFamily(globals, PM_FAMILY_INTERFACES);
    // Set appid for config manager preparsing
    SetActionAppId(globals, APPID_PTP);

    WriteAction(globals);

    if (CliCheckAll(globals))
        return;

    if(CliDebugMip(globals))
        printf("WRPesmPtPConfig(\n"
                "\tnum of object  %d)\n", objCount);

    WRPset(globals, APPID_PTP, SNAPID_PTP_MIP);
    WRPwriteTable(globals, MIP_ALAPTPCONFIGURATION);
    WRPwriteIndex(globals, 0, NULL);

    for (onum = 0; onum < objCount; onum++)
        WRPwriteObject(globals, EsmList[onum].objNum, 
          EsmList[onum].objType, EsmList[onum].objLength, 
          EsmList[onum].objValue);

    WRPmip_msg_done(globals);
    WRPmip_free_buffer(globals);
}

void WRPesmShowPtPConfig(CliSubparserGlobals *globals)
{
    MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
    int32       mipIndexLength = 0;
    int32       done;

    SetActionAllFamily(globals, PM_FAMILY_INTERFACES, PARTM_EUP_AREA_PHYSICAL);
    ReadAction(globals);
    if (CliCheckAll(globals))
        return;

    if(CliDebugMip(globals))
        printf("%s()\n",__FUNCTION__);
    	
    do{
        WRPshow(globals, APPID_PTP, SNAPID_PTP_MIP);
        if (mipIndexLength == 0)
            WRPmip_write_ascii_all(globals, MIP_ALL);
        WRPmip_write_ascii_req(globals, 1,  MIP_DISP_INTERFACES_PTP_CONFIG, mipIndexLength, mipIndex);
        done = WRPdone(globals, &mipIndexLength, mipIndex);
    }while(!done);
}

void WPREsmMacSecConfig(CliSubparserGlobals *globals, EsmPropagateGlobals* prog)
{
    int tableCount;
    int objCount;
    EsmObjectList* objList = NULL;
    SetActionAllFamily(globals,  PM_FAMILY_INTERFACES, PARTM_EUP_AREA_PHYSICAL);
    // Set appid for config manager preparsing
    SetActionAppId(globals, APPID_ESM_DRIVER);
    WriteAction(globals);
    if (CliCheckAll(globals))
        return;

    if(CliDebugMip(globals))
        printf("WPREsmMacSecConfig(\n"
                "\ttableCount             %d\n"
                "\tstart_ifIndex_field    %d\n"
                "\tend_ifIndex_field      %d\n"
                , prog->tableCount, prog->tableList[0].mipIndex[0], prog->tableList[0].mipIndex[1]);
    if(prog->tableCount == 0) {
        globals->cliGlobals->error = CLI_EXIT;
        return;
    }
        
    for (tableCount = 0; tableCount < prog->tableCount; tableCount++)   
    {
        WRPsetLarge(globals, APPID_ESM_DRIVER, SNAPID_CMM_ESM_DRIVER_MIP);
        WRPwriteTable(globals, prog->tableList[tableCount].table_id );
        WRPwriteIndex(globals, prog->tableList[tableCount].indexlen, prog->tableList[tableCount].mipIndex);
        for(objCount = 0; objCount < prog->tableList[tableCount].objCount; objCount++)
        {
           objList = &(prog->tableList[tableCount].objList[objCount]);
           WRPwriteObject(globals, objList->objNum, objList->objType, objList->objLength,objList->objValue);
        }
        if(CliDebugMip(globals)) {
            WRPmip_msg_done(globals);      
        } else {
            if (WRPmip_msg_done(globals) == MIP_DONE) 
            { 
                // Wait for response
                if(tableCount < (prog->tableCount - 1) ) 
                {
                    if (WRPmip_msg_nowait_response(globals) != MIP_DONE) {
                        globals->cliGlobals->error = CLI_EXIT;
                        return;
                    }
                }       
            } else 
                return;
        }
    }

    WRPmip_free_buffer(globals);

}

void WRPEsmShowMacSec(CliSubparserGlobals *globals, int table, int start_ifIndex_field, int end_ifIndex_field,  int count)
{
    MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
    int32       mipIndexLength=0;
    int32       done;
    
    if((!CS_AmI6860()) && (!CS_AmI9900()) && (!CS_AmI6465())){
         SetFormatedDisplay(CliGetDisplayGlobals(globals), ASCII_ERROR_INVALID_PLATFORM);
         globals->cliGlobals->error = 5;
         return;
    }

    SetActionAllFamily(globals,  PM_FAMILY_INTERFACES, PARTM_EUP_AREA_PHYSICAL);
    ReadAction(globals);
    if (CliCheckAll(globals))
        return;

    if(CliDebugMip(globals))
        printf("WRPEsmShowMacSec(\n"
               "\ttable                  %d\n"
                "\tstart_ifIndex_field    %d\n"
                "\tend_ifIndex_field      %d\n"
                "\tcount                  %d)\n"
                , table, start_ifIndex_field, end_ifIndex_field, count);
    if(count == 0)
    {
        mipIndex[0] = 0;
        mipIndex[1] = 0;
        mipIndexLength = 2;
    }
    else
    {
        mipIndex[0] = 0;       
        mipIndex[1] = start_ifIndex_field;
        mipIndex[2] = end_ifIndex_field;
        mipIndexLength = 3;
    }
    
    do
    {
        WRPshow(globals, APPID_ESM_DRIVER, SNAPID_CMM_ESM_DRIVER_MIP);
        if (count == 0)
            WRPmip_write_ascii_all(globals, MIP_ALL);
        WRPmip_write_ascii_req(globals, 1, table, mipIndexLength, mipIndex);
        done = WRPdone(globals, &mipIndexLength, mipIndex);
    } while (!done);
}

/******************************************************************************
   Function Name: fillObjList
   Description  : 
 ******************************************************************************/
void fillObjMacSec( EsmTableList* table, int32 objNum, int32 value, int32 mip_type)
{   
    table->objList[table->objCount].objNum = objNum;  
    memcpy((char*)table->objList[table->objCount].objValue,  &value, 4);
    table->objList[table->objCount].objLength = 4;
    table->objList[table->objCount].objType = mip_type;
    table->objCount++;
}

void fillObjMacSecSci(EsmTableList* table, int32 objNum, uint8* value)
{    
    table->objList[table->objCount].objNum = objNum;
    int len = 8;
    memcpy(table->objList[table->objCount].objValue,
            value, len);
    table->objList[table->objCount].objLength = len;
    table->objList[table->objCount].objType = MIP_STRING;
    table->objCount++;
}
void hexStrToSci(char* sci16, uint8* sci8)
{
    int32 idx;
    char sci_temp[16];
    uint32 temp[8];
    for( idx = 0; idx < (MAX_SCI_LEN  - strlen(sci16)); idx++)
    {
        sci_temp[idx] = '0';
    }
    memcpy((char*) (sci_temp + idx ), (char*)(sci16 + 2), strlen(sci16) - 2 );
    sscanf(sci_temp,"%2x%2x%2x%2x%2x%2x%2x%2x",&temp[0],&temp[1],&temp[2],&temp[3],&temp[4],&temp[5],&temp[6],&temp[7]);
    for( idx =0; idx < 8; idx++)
    {
        sci8[idx] = (uint8)temp[idx];
    }
}

void WRPesmInterfaceTypeSLOTPORTNoMacsecStatisticsAll(CliSubparserGlobals *globals)
{
    MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
    int32       mipIndexLength = 0;
    int32       done;

    SetActionAllFamily(globals, PM_FAMILY_INTERFACES, PARTM_EUP_AREA_PHYSICAL);
    ReadAction(globals);
    if (CliCheckAll(globals))
        return;

    if(CliDebugMip(globals))
        printf("%s()\n",__FUNCTION__);

    mipIndex[0]=0;
    mipIndex[1]=0;
    mipIndexLength=2;

    do{
        WRPshow(globals, APPID_ESM_DRIVER, SNAPID_CMM_ESM_DRIVER_MIP);
        if (!mipIndex[1])
            WRPmip_write_ascii_all(globals, MIP_ALL);
        WRPmip_write_ascii_req(globals, 1,  MIP_RESET_ALL_INTERFACES_MACSEC_STATS, mipIndexLength, mipIndex);
        done = WRPdone(globals, &mipIndexLength, mipIndex);
    }while(!done);
}
void WRPdebugInterfacesMacsec(CliSubparserGlobals *globals,uint32 ifIndex_1_field,uint32 ifIndex_2_field,int table_id)
{
    MIP_OIDC mipIndex[CLI_MIP_IDX_LENGTH];
    int32 mipIndexLength;
    int32 done;
    int32 first;

    SetActionFuncFamily(globals,PM_FAMILY_DEBUG);
    WriteAction(globals);
    if(CliCheckAll(globals))
        return;

    if(CliDebugMip(globals))
		printf("WRPdebugInterfacesMacsec(\n"
			   "\tint ifIndex_1_field %u\n"
			   "\tint ifIndex_2_field %u\n",
				ifIndex_1_field,ifIndex_2_field);

                
    mipIndexLength=2;
	mipIndex[0]=ifIndex_1_field;
	mipIndex[1]=ifIndex_2_field;

    first=1;

    do
	{
		WRPdebug(globals,APPID_ESM_DRIVER,SNAPID_CMM_ESM_DRIVER_MIP,first);
		first=0;
		WRPmip_write_ascii_req(globals,MIP_ASCII_DEBUG,table_id,mipIndexLength,mipIndex);
		done=WRPdone(globals,&mipIndexLength,mipIndex);
	}while(!done);
}

void WRPptpPortAdminState(CliSubparserGlobals *globals, int startIfIndex, int endIfIndex, int adminState)
{
    MIP_OIDC mipIndex[CLI_MIP_IDX_LENGTH];
    int32 mipIndexLength;

    SetActionFuncFamily(globals, PM_FAMILY_INTERFACES);
    // Set appid for config manager preparsing
    SetActionAppId(globals, APPID_PTP);

    WriteAction(globals);

    if (CliCheckAll(globals))
        return;

    if(CliDebugMip(globals))
        printf("WRPptpPortAdminState(\n"
                "\tStart IfIndex:  %d\n"
                "\tEnd IfIndex:  %d\n"
                "\tAdmin State:  %d)\n"
                , startIfIndex, endIfIndex, adminState);
    
    mipIndex[0] = startIfIndex;
    mipIndex[1] = endIfIndex;
    mipIndexLength = 2;

    WRPset(globals, APPID_PTP, SNAPID_PTP_MIP);
    WRPwriteTable(globals, MIP_ALAPTPPORTTABLE);
    WRPwriteIndex(globals, mipIndexLength, mipIndex);
    WRPwriteObject(globals, mip_alaPtpPortAdminStatus, MIP_INT32, 4, (uint8*)&adminState);

    WRPmip_msg_done(globals);
    WRPmip_free_buffer(globals);
}

void WPRTptpLoopbackConfig(CliSubparserGlobals *globals, EsmPropagateGlobals* prog)
{
    int tableCount = 0;
    int objCount;
    EsmObjectList* objList = NULL;
    SetActionFuncFamily(globals, PM_FAMILY_INTERFACES);
    // Set appid for config manager preparsing
    SetActionAppId(globals, APPID_PTP);
    WriteAction(globals);
    if (CliCheckAll(globals))
        return;	 

    if(CliDebugMip(globals))
        printf("WPRTptpLoopbackConfig(\n"
                "\ttableCount             %d\n"
                , prog->tableCount);
    if(prog->tableCount == 0) {
        globals->cliGlobals->error = CLI_EXIT;
        return;
    }

    WRPsetLarge(globals, APPID_PTP, SNAPID_PTP_MIP);
    WRPwriteTable(globals, prog->tableList[tableCount].table_id );
    WRPwriteIndex(globals, prog->tableList[tableCount].indexlen, prog->tableList[tableCount].mipIndex);
    for(objCount = 0; objCount < prog->tableList[tableCount].objCount; objCount++)
    {
       objList = &(prog->tableList[tableCount].objList[objCount]);
       WRPwriteObject(globals, objList->objNum, objList->objType, objList->objLength,objList->objValue);
    }
    WRPmip_msg_done(globals);
    WRPmip_free_buffer(globals);
}

