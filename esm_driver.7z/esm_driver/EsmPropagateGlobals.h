#ifndef ESMPROPAGATEGLOBALSH
#define ESMPROPAGATEGLOBALSH
#include "esmDrv_lib.h"

typedef struct _EsmObjectList {
        uint8 objNum;
        MIP_OBJ_TYPE objType;
        uint16 objLength;
        uint8 objValue[128];
} EsmObjectList;

typedef struct _EsmTableList {
    int32 table_id;
    EsmObjectList objList[20];
    int32 objCount;
    int32 indexlen;
    MIP_OIDC    mipIndex[CLI_MIP_IDX_LENGTH];
} EsmTableList;

typedef struct _EsmPropagateGlobals{

	/*TO DO: add declarations of propagation parameters below*/
//	cliSlotPort  esmSlotPort[CLI_MAX_SLOT_PORT_RANGES];
	cliChassisSlotPort  esmSlotPort[CLI_MAX_SLOT_PORT_RANGES];
	int32        slotPortCount;
	int32		 slot;
	int			 userPortRowStatus;

//	cliSlotPort	 esmNetSlotPort[CLI_MAX_SLOT_PORT_RANGES];
	cliChassisSlotPort	 esmNetSlotPort[CLI_MAX_SLOT_PORT_RANGES];
	int			 netSlotPortCount;
    int			 netPortRowStatus;
    aggRange        aggRangeList[CLI_MAX_SLOT_PORT_RANGES];
    int         aggRangeCount;
    LFP_PORT_INFO   aggPortType[CLI_MAX_SLOT_PORT_RANGES];
    LFP_PORT_INFO   phyPortType[CLI_MAX_SLOT_PORT_RANGES];
    uint64          loopingCheck;
    uint64          currentOption;
    EsmObjectList   objList[150];
	int32           objCount;
    EsmTableList    tableList[10];
    int32           tableCount;  
    uint32 macsec_debug;
    int portListObject[8];
} EsmPropagateGlobals;

#endif
