#ifndef MANAGEMENT_SRC_ESMPARSEWRAPPERS_H
#define MANAGEMENT_SRC_ESMPARSEWRAPPERS_H

#ifdef __cplusplus
extern "C" {
#endif


#include "CliParserGlobals.h"
#include "CliUtilities.h"
#include "esmDrv_lib.h"
#include "EsmPropagateGlobals.h"
/* User Constants */
#define	LINKAGG			0

#define PORTMAP_UNIDIRECTIONAL 1
#define PORTMAP_BIDIRECTIONAL  2

#define	PORTMAP_USER		   1
#define PORTMAP_NETWORK		   2

#define ESM_TYPE_BCAST		0
#define ESM_TYPE_MCAST		1
#define ESM_TYPE_UUCAST		2
#define ESM_TYPE_INGRESS	3

#define ESM_STORM_DEFAULT	1
#define ESM_STORM_TRAP		2
#define ESM_STORM_SHUTDOWN	3

#define ESM_LIM_TYPE_MBPS 		1
#define ESM_LIM_TYPE_PERCENT 	2
#define ESM_LIM_TYPE_PPS 		3
#define ESM_LIM_TYPE_DEFAULT	4
#define ESM_LIM_TYPE_ENADIS		5

#define ESM_LIM_ENABLE		1
#define ESM_LIM_DISABLE		2

#define ESM_NO_BURST  0

#define ESM_SPEED_10 		2
#define ESM_SPEED_100 		1
#define ESM_SPEED_1000 		5
#define ESM_SPEED_10000 	6
#define ESM_SPEED_40000 	7
#define ESM_SPEED_MAX_100 	8
#define ESM_SPEED_MAX_1000 	9
#define ESM_SPEED_AUTO		3
#define ESM_SPEED_2000         13
#define ESM_SPEED_4000         14
#define ESM_SPEED_8000         15
#define ESM_SPEED_MAX_4000     16
#define ESM_SPEED_MAX_8000     17
#define ESM_SPEED_2500         18
#define ESM_SPEED_5000         19
#define ESM_SPEED_MAX_2500     20
#define ESM_SPEED_MAX_5000     21 

#define ESM_BIT_1          ((uint64)1 << 1)
#define ESM_BIT_2          ((uint64)1 << 2)
#define ESM_BIT_3          ((uint64)1 << 3)

#define DO_NOT_SET	-1
#define PTPCONFIG_PRIORITY_DEFAULT 7

#define STATISTICS          1     
#define ENCRYPTION          1
#define KEY_CHAIN           2
#define MAX_SCI_LEN         18

#define MAX_PTP_LOOPBACK_PORT 8

void WRPesmShowInterfacesXXX(CliSubparserGlobals *globals, int table, int type,
    int start_ifIndex_field, int end_ifIndex_field,
    int count, cliChassisSlotPort *slotport);
void WRPesmShowInterfacesEmp(CliSubparserGlobals *globals);

void WRPesmInterfaceTypeSLOTPORTSpeed(CliSubparserGlobals *globals, int val, int slot, int count, cliChassisSlotPort *slotport);
void WRPesmInterfaceTypeSLOTPORTDuplex(CliSubparserGlobals *globals, int val, int slot, int count, cliChassisSlotPort *slotport);
void WRPesmInterfaceTypeSLOTPORTAdminUp(CliSubparserGlobals *globals, int val, int slot, int count, cliChassisSlotPort *slotport);
void WRPesmInterfaceTypeSLOTPORTSplitMode(CliSubparserGlobals *globals, int val, int chassisId_field, int count, cliChassisSlotPort *slotport);
void WRPesmInterfaceTypeSLOTPORTBeaconParam(CliSubparserGlobals *globals, int ledAdminState,int ledColor,int ledMode, int chassisId_field,
                                            int count, cliChassisSlotPort *slotport,int portRowStatus);
void WRPesmInterfaceTypeSLOTPORTNoL2Statistics(CliSubparserGlobals *globals, int slot, int count, cliChassisSlotPort *slotport);
void WRPesmInterfaceTypeSLOTPORTNoL2StatisticsCli(CliSubparserGlobals *globals, int slot, int count, cliChassisSlotPort *slotport);
void WRPesmInterfaceTypeSLOTPORTNoL2StatisticsAll(CliSubparserGlobals *globals);
void WRPesmInterfaceTypeSLOTPORTMaxFrame(CliSubparserGlobals *globals, int val, int slot, int count, cliChassisSlotPort *slotport);
void WRPesmTrapSLOTPORTPortLinkONOFF(CliSubparserGlobals *globals, int val, int slot, int count, cliChassisSlotPort *slotport);
void WRPesmInterfaceEppEnableDisable(CliSubparserGlobals *globals,int val_field,int slot_field,int count_field,cliChassisSlotPort *slot_port);
void WRPesmInterfaceEeeEnableDisable(CliSubparserGlobals *globals,int val_field,int chassisId_field,int count_field,cliChassisSlotPort *slot_port);

void WRPesmInterfaceTypeSLOTFloodMulticast(CliSubparserGlobals *globals, int slot, int val);
void WRPesmInterfaceTypeSLOTPORTAlias(CliSubparserGlobals *globals, char *str0, int slot, int count, cliChassisSlotPort *slotport);


void WRPesmInterfaceTypeSLOTPORTClearViolationAll(CliSubparserGlobals *globals, int val, int slot, 
                                    int count, cliChassisSlotPort *slotport);
void WRPesmInterfaceESMCONFTABLE(CliSubparserGlobals *globals, int obj, int val, int slot, int count, cliChassisSlotPort *slotport);
void WRPesmInterfaceESMPAUSETABLE(CliSubparserGlobals *globals, int obj, int val, int slot, int count, cliChassisSlotPort *slotport);
void WRPesmInterfaceTraffic(CliSubparserGlobals *globals, int type, int lim_val, int lim_type, int lim_enable, int burst, int slot, int count, cliChassisSlotPort *slotport,int lowval);
void WRPesmInterfaceTypeSLOTPORTFloodAction(CliSubparserGlobals *globals, int type, int val,
						int chassisId_field, int count, cliChassisSlotPort *slotport);
void WRPesmInterfaceIfgSet(CliSubparserGlobals *globals,int val_field,int slot_field,int count_field,cliChassisSlotPort *slot_port);
void WRPesmPtPConfig(CliSubparserGlobals *globals, EsmObjectList *EsmList, int32 objCount);
void WRPesmShowPtPConfig(CliSubparserGlobals *globals);

/* Port Mapping */

void WRPesmPortMappingShow(CliSubparserGlobals *globals, int session, int table);

void WRPesmDebugInterfacesXXX(CliSubparserGlobals *globals, int table, int int0, int int1);
void WRPesmDebugInterfacesHighPowerMode(CliSubparserGlobals *globals, int int0, int int1);
void WRPesmDebugInterfacesLowPowerMode(CliSubparserGlobals *globals, int int0, int int1);
void WRPdebugInterfacesLowLatency(CliSubparserGlobals *globals,int ifIndex_1_field,int ifIndex_2_field, int status_field);
void WRPdebugInterfacesShowLowLatency(CliSubparserGlobals *globals,int ifIndex_1_field,int ifIndex_2_field);
void WRPdebugInterfacesShow(CliSubparserGlobals *globals,int ifIndex_1_field,int ifIndex_2_field,int table_id);
void WRPdebugInterfacesEnableDisable(CliSubparserGlobals *globals,int ifIndex_1_field,int ifIndex_2_field,int status_field,int table_id);
void WRPdebugInterfacesFirmwareDownload(CliSubparserGlobals *globals,uint32 slot_field,char *filename_with_path);

void WRPesmSetEnableDisable(CliSubparserGlobals *globals, int mibObject, int enable);
void WRPesmInterfaceTdrState(CliSubparserGlobals *globals, uint32 start_ifIndex_field, uint32 end_ifIndex_field, int state_field);
void WRPesmInterfaceClearTdrStatistics(CliSubparserGlobals *globals, uint32 start_ifIndex_field, uint32 end_ifIndex_field);


/* Port Manager */

void WRPesmPmClearSLOTPORT(CliSubparserGlobals *globals, int ndx1, int ndx2);
void WRPesmShowPm(CliSubparserGlobals *globals, int ndx1, int ndx2, int table);
void WRPesmInterfaceTypeSLOTPORTLinkMonConfig(CliSubparserGlobals *globals, int val,int chassisId_field,int count, 
        cliChassisSlotPort *slotport,MIP_OBJ_TYPE objType);
void WRPesmInterfaceTypeSLOTPORTLinkMonStats(CliSubparserGlobals *globals, int val,
        int chassisId_field, 
           int count, cliChassisSlotPort *slotport,MIP_OBJ_TYPE objType);
void WRPesmViolationGlobalAutoRecovery(CliSubparserGlobals *globals, int val, int violationType);
void WRPesmViolationAutoRecovery(CliSubparserGlobals *globals, int start_ifIndex_field, int end_ifIndex_field, int val, int violationType);
void WRPesmSetViolationEnableDisable(CliSubparserGlobals *globals, int enable);	

/* Link Fault Propagation */
void WRPesmLFPCreateGroup(CliSubparserGlobals *globals, int groupId);
void WRPesmLFPDeleteGroup(CliSubparserGlobals *globals, int groupId1, int groupId2);
void WRPesmLFPConfigGroup(CliSubparserGlobals *globals, int groupId, int status, int timer);
void WRPesmLFPPortConfig(CliSubparserGlobals *globals, int groupId, int status,
        cliChassisSlotPort *portRange, LFP_PORT_INFO *portType, int portCount,
        aggRange    *aggRange,  LFP_PORT_INFO *aggType,  int aggCount);
void WRPesmShowLFPGroupConfig(CliSubparserGlobals *globals, int option);
void WRPesmLFPDeleteGroup(CliSubparserGlobals *globals, int groupId1, int groupId2);
void WRPpmShowInterfacesXXX(CliSubparserGlobals *globals, int table, int type,
    int start_ifIndex_field, int end_ifIndex_field,
    int count, cliChassisSlotPort *slotport);
void WRPpmInterfaceESMCONFTABLE(CliSubparserGlobals *globals, int obj, int val, int slot,
        int count, cliChassisSlotPort *slotport);
/* MacSec propagation */

void WRPEsmShowMacSec(CliSubparserGlobals *globals, int table, int start_ifIndex_field, int end_ifIndex_field,  int count);
void fillObjMacSec( EsmTableList* table, int32 objNum, int32 value, int32 mip_type);
void fillObjMacSecSci(EsmTableList* table, int32 objNum, uint8* value);
void WPREsmMacSecConfig(CliSubparserGlobals *globals, EsmPropagateGlobals* prog);
void hexStrToSci(char* sci16, uint8* sci8);
void WRPesmInterfaceTypeSLOTPORTNoMacsecStatisticsAll(CliSubparserGlobals *globals);
void WRPdebugInterfacesMacsec(CliSubparserGlobals *globals,uint32 ifIndex_1_field,uint32 ifIndex_2_field,int table_id);

void WRPptpPortAdminState(CliSubparserGlobals *globals, int startIfIndex, int endIfIndex, int adminState);
void WPRTptpLoopbackConfig(CliSubparserGlobals *globals, EsmPropagateGlobals* prog);
#ifdef __cplusplus
}
#endif

#endif /* MANAGEMENT_SRC_ESMPARSEWRAPPERS_H */
